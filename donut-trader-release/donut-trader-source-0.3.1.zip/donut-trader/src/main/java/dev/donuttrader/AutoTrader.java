package dev.donuttrader;

import com.google.gson.GsonBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;

/** One-command, single-position auction runner. No configured confirmation slots are used. */
public final class AutoTrader {
    private enum Step { DATA, OPEN, PAGE, OWN_OPEN, OWN_MAIN, OWN_PAGE, BUY, DELIVERY, HAND, SWAP, READY,
        SELL, RETURN_HAND, RESTORE, PAUSE, STOPPED }
    private final Config cfg;
    private final SpendLedger ledger;
    private final WebMarket web;
    private final OfficialMarket official;
    private final TradingJournal journal;
    private final Path ledgerFile;
    private final List<String> watch;
    private Step step = Step.DATA;
    private long tick, since, stableSince, swapEpoch, receiptEpoch;
    private String stable = "", target = "", lastStatus = "";
    private int watchIndex, page = 1, expectedPage = 1, priorOwnId, oldSelected = -1, handSlot, swapIndex = -1;
    private boolean checkingBefore, sellDialogClicked, purchaseConfirmed, restoreNeeded;
    private ItemStack item = ItemStack.EMPTY, displaced = ItemStack.EMPTY;
    private Market.Deal pending;
    private PriceQuote purchaseQuote;
    private String precheckedKey = "";
    private int precheckedCount;
    private long precheckedAt, precheckedPrice;
    private int listed;
    private long scannedPages, scannedListings;
    private boolean dashboardPaused;
    private final List<TraderDashboard.Offer> offers = new ArrayList<>();

    public AutoTrader(Config cfg, SpendLedger ledger, WebMarket web, OfficialMarket official,
                      TradingJournal journal, Path ledgerFile) {
        this.cfg = cfg; this.ledger = ledger; this.web = web; this.ledgerFile = ledgerFile;
        this.official = official; this.journal = journal;
        if (!ledger.unresolved.isBlank()) throw new IllegalStateException("Önceki belirsiz işlem: " + ledger.unresolved);
        if (ledger.currencyScale != 2) throw new IllegalStateException("Bütçe defteri hazır değil");
        if (cfg.allowedItems.isEmpty()) for (String id : AutoPolicy.WATCH) cfg.allowedItems.add("minecraft:" + id);
        watch = cfg.allowedItems.stream().filter(id -> id.matches("minecraft:[a-z0-9_]+") && !cfg.blockedItems.contains(id)).sorted().toList();
        if (watch.isEmpty()) throw new IllegalStateException("İşlem yapılacak standart eşya yok");
        say("AUTO açık: eşya arama, sayfa tarama, onay ve yeniden ilan. Toplam limit=" + cfg.budget
            + "; asgari tahmini net kâr=%" + Math.round(cfg.minNetMargin * 100) + "; komisyon hesabı=%" + Math.round(fee() * 100) + " (tahmin). /dt stop durdurur.");
    }
    public boolean active() { return step != Step.STOPPED; }
    public String status() { return "AUTO " + step + " | " + target + " | sayfa=" + scannedPages + " ilan=" + scannedListings + " | doğrulanan ilan=" + listed + " | ayrılan=" + Market.formatMinor(ledger.committed) + "/" + cfg.budget + " | " + lastStatus; }
    public String phase() { return dashboardPaused ? "PANEL ACIK / BEKLIYOR" : step.name(); }
    public String target() { return target; }
    public String reason() { return lastStatus; }
    public long scannedPages() { return scannedPages; }
    public long scannedListings() { return scannedListings; }
    public List<TraderDashboard.Offer> offers(long now) {
        return offers.stream().filter(o -> now >= o.seenMillis() && now - o.seenMillis() <= 60_000).toList();
    }
    private double fee() { return Math.max(.10, cfg.saleFee); }
    private long remaining() { return Math.max(0, Market.toMinor(cfg.budget) - ledger.committed); }
    private void enter(Step next) { step = next; since = tick; stable = ""; stableSince = tick; }
    private void note(String message) { if (!message.equals(lastStatus)) { say(message); lastStatus = message; } }
    private static void say(String s) { var p=Minecraft.getInstance().player; if(p!=null)p.displayClientMessage(Component.literal("[DonutTrader] " + s),false); }
    public void stop(String reason) {
        step = Step.STOPPED;
        lastStatus = reason;
        restoreSelection(Minecraft.getInstance());
        say(reason + (ledger.unresolved.isBlank() ? "" : " | İşlem belirsiz kaydedildi; otomatik tekrar yapılmayacak."));
        journal.event("AUTO durdu: " + reason);
    }
    private void save() throws Exception {
        Path tmp = Files.createTempFile(ledgerFile.getParent(), "donut-auto-", ".tmp");
        try {
            Files.writeString(tmp,new GsonBuilder().setPrettyPrinting().create().toJson(ledger));
            Files.move(tmp,ledgerFile,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(tmp); }
    }
    private static String key(ItemStack s) {
        if (s.isEmpty()) return "";
        ItemStack copy=s.copy();copy.remove(DataComponents.LORE);copy.setCount(1);
        return BuiltInRegistries.ITEM.getKey(copy.getItem()) + "|" + copy.getComponents();
    }
    private static boolean plain(ItemStack s) {
        if (s.isEmpty())return false; ItemStack copy=s.copy();copy.remove(DataComponents.LORE);copy.setCount(1);
        return ItemStack.isSameItemSameComponents(copy,new ItemStack(copy.getItem()));
    }
    private static Optional<PriceQuote> quote(ItemStack stack) {
        var lore=stack.get(DataComponents.LORE); if(lore==null)return Optional.empty();
        PriceQuote found=null;
        for(var line:lore.lines()) {
            String text=line.getString().replaceAll("§.","").strip();
            var amounts=Pattern.compile("(?i)\\$\\s*([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]+)?\\s*[kmb]?)(?![0-9A-Za-z.,])").matcher(text);
            while(amounts.find()) {
                if(found!=null)return Optional.empty();
                try {found=PriceQuote.parse(amounts.group());}catch(IllegalArgumentException invalid){return Optional.empty();}
            }
        }
        return Optional.ofNullable(found);
    }
    private static int count(Minecraft mc,String wanted) {
        int n=0;for(int i=0;i<36;i++){var s=mc.player.getInventory().getItem(i);if(key(s).equals(wanted))n+=s.getCount();}return n;
    }
    private boolean exactHeld(Minecraft mc) {
        var held=mc.player.getInventory().getItem(handSlot);
        return key(held).equals(pending.listing().key())&&held.getCount()==pending.listing().count();
    }
    private static boolean cursorEmpty(Minecraft mc) { return mc.player.containerMenu.getCarried().isEmpty(); }
    private static String title(Minecraft mc) {return mc.screen==null?"":mc.screen.getTitle().getString();}
    private static boolean auction(Minecraft mc) {return mc.screen instanceof AbstractContainerScreen<?> && title(mc).matches(AuctionProfile.TITLE);}
    private static int page(Minecraft mc) {
        var m=Pattern.compile("^Auction \\(Page ([1-9][0-9]*)\\)$").matcher(title(mc));return m.matches()?Integer.parseInt(m.group(1)):-1;
    }
    private static boolean own(Minecraft mc) { return mc.screen instanceof AbstractContainerScreen<?> && title(mc).toLowerCase(Locale.ROOT).contains("your items"); }
    private static AbstractContainerScreen<?> screen(Minecraft mc) {return (AbstractContainerScreen<?>)mc.screen;}
    private boolean stable(Minecraft mc) {
        if(!cursorEmpty(mc))return false;
        var menu=screen(mc).getMenu();String value=menu.containerId+":"+menu.getStateId()+":"+title(mc);
        if(!value.equals(stable)){stable=value;stableSince=tick;return false;}
        return tick-stableSince>=5 && tick-since>=10;
    }
    private static void click(Minecraft mc,int slot,int button,ClickType type) {
        if(!cursorEmpty(mc))throw new IllegalStateException("İmleçte eşya var; işlem yapılmadı");
        var menu=mc.player.containerMenu;
        mc.gameMode.handleInventoryMouseClick(menu.containerId,slot,button,type,mc.player);
    }
    private boolean openCommand(Minecraft mc,String command) {
        if(mc.screen instanceof AbstractContainerScreen<?>) {if(!cursorEmpty(mc))return false;mc.player.closeContainer();return false;}
        if(mc.screen!=null && !(mc.screen instanceof ChatScreen))throw new IllegalStateException("Beklenmeyen ekran: "+title(mc));
        if(tick-since<8)return false;
        mc.player.connection.sendCommand(command);return true;
    }
    private void nextTarget() {
        pending=null;item=ItemStack.EMPTY;precheckedKey="";page=expectedPage=1;
        watchIndex=(watchIndex+1)%watch.size();target=watch.get(watchIndex);enter(Step.OPEN);
    }
    public void tick(Minecraft mc) {
        if(!active())return;
        if(mc.screen instanceof TraderDashboard) {dashboardPaused=true;return;}
        if(dashboardPaused) {
            dashboardPaused=false;
            if(ledger.unresolved.isBlank()){pending=null;precheckedKey="";target=watch.get(watchIndex);page=expectedPage=1;enter(Step.OPEN);}
        }
        tick++;
        try {
            if(mc.player==null||mc.gameMode==null||mc.getCurrentServer()==null) {stop("Bağlantı kapandı.");return;}
            String host=mc.getCurrentServer().ip.toLowerCase(Locale.ROOT).split(":",2)[0], expected=cfg.serverHost.toLowerCase(Locale.ROOT);
            if(!host.equals(expected)&&!host.endsWith("."+expected)){stop("Sunucu değişti.");return;}
            if(step!=Step.DATA && step!=Step.PAUSE && tick-since>600) {
                if(ledger.unresolved.isBlank()){note("Yanıt alınamadı; sonraki eşya aranıyor.");nextTarget();return;}
                throw new IllegalStateException("Sunucu yanıtı zaman aşımına uğradı: "+step);
            }
            switch(step) {
                case DATA -> {
                    web.refresh(System.currentTimeMillis());
                    official.refresh(System.currentTimeMillis());
                    if(web.prices(System.currentTimeMillis()).isEmpty()&&official.stats(System.currentTimeMillis()).isEmpty()){
                        note("Dis fiyat referansi yok; canli ilan karsilastirmasi kullaniliyor. Gercek satis talebi bilinmiyor.");
                    }
                    if(remaining()==0){stop("10 milyonluk toplam alış limiti doldu.");return;}
                    target=watch.get(watchIndex);enter(Step.OPEN);
                }
                case OPEN -> {
                    if(remaining()==0){stop("Toplam alış limiti doldu.");return;}
                    if(openCommand(mc,"auction "+target.substring("minecraft:".length()))){expectedPage=page;enter(Step.PAGE);}
                }
                case PAGE -> {
                    if(auction(mc)&&page(mc)==expectedPage&&stable(mc))scan(mc);
                }
                case OWN_OPEN -> {if(openCommand(mc,"auction"))enter(Step.OWN_MAIN);}
                case OWN_MAIN -> {
                    if(!auction(mc)||!stable(mc))return;
                    var menu=screen(mc).getMenu();
                    if(menu.slots.size()<=51||!menu.getSlot(51).getItem().getHoverName().getString().strip().equalsIgnoreCase("Your Items"))
                        throw new IllegalStateException("Your Items kontrolü tanınmadı");
                    priorOwnId=menu.containerId;click(mc,51,0,ClickType.PICKUP);enter(Step.OWN_PAGE);
                }
                case OWN_PAGE -> {
                    if(!own(mc)||!stable(mc))return;
                    var ownMenu=screen(mc).getMenu();
                    if(ownMenu.slots.size()>53&&ownMenu.getSlot(53).getItem().getHoverName().getString().strip().equalsIgnoreCase("Next page"))
                        throw new IllegalStateException("Your Items birden çok sayfa; bu sürümde tekil yeni ilan kanıtı kurulamıyor");
                    int matches=ownMatches(mc);
                    if(checkingBefore) {
                        if(matches!=0){note("Bu eşyadan zaten aktif ilan var; sonraki eşya.");nextTarget();return;}
                        precheckedKey=pending.listing().key();precheckedCount=pending.listing().count();precheckedPrice=pending.salePrice();precheckedAt=tick;
                        page=expectedPage=1;enter(Step.OPEN);
                    } else {
                        if(!AutoPolicy.ownListingProven(0,matches))throw new IllegalStateException("Yeni ilan tekil olarak doğrulanamadı; eşleşme="+matches);
                        ledger.unresolved="";save();listed++;restoreSelection(mc);
                        journal.listed(target,pending.listing().count(),pending.listing().price(),pending.salePrice(),pending.netProfit());
                        say("Yeniden ilan doğrulandı: "+target+" x"+pending.listing().count()+" @"+Market.formatMinor(pending.salePrice())+". Henüz gerçekleşmiş satış değil.");
                        nextTarget();enter(Step.PAUSE);
                    }
                }
                case BUY -> {
                    if(deliveryProven(mc)&&!NativeDialogs.isDialog(mc.screen)) {
                        purchaseConfirmed=true;
                        note("Doğrudan teslim doğrulandı; maliyet için ilanın üst fiyat sınırı ayrılmış kalır.");
                        enter(Step.HAND);return;
                    }
                    if(tick-since>=6 && NativeDialogs.confirmPurchase(mc,item,purchaseQuote.lowerMinor(),purchaseQuote.upperMinor())){
                        purchaseConfirmed=true;enter(Step.DELIVERY);
                    }
                }
                case DELIVERY -> {
                    int amount=count(mc,pending.listing().key());
                    if(amount>pending.listing().count())throw new IllegalStateException("Teslim adedi beklenenden fazla");
                    if(amount==pending.listing().count()&&deliveryProven(mc)) {
                        if(NativeDialogs.isDialog(mc.screen))mc.setScreen(null);
                        enter(Step.HAND);
                    }
                }
                case HAND -> prepareHand(mc);
                case SWAP -> {
                    if(AutoPolicy.serverSwapProven(swapEpoch,InventoryEvidence.slotEpoch(handSlot),exactHeld(mc))){select(mc,handSlot);enter(Step.READY);}
                }
                case READY -> {
                    if(tick-since<8)return;
                    if(!exactHeld(mc)||!cursorEmpty(mc))throw new IllegalStateException("Satılacak eldeki eşya değişti");
                    if(mc.screen!=null){mc.player.closeContainer();return;}
                    ledger.unresolved="Satış komutu bekleniyor: "+target+" @"+Market.formatMinor(pending.salePrice());save();
                    sellDialogClicked=false;
                    receiptEpoch=InventoryEvidence.epoch();
                    mc.player.connection.sendCommand("auction sell "+Market.formatMinor(pending.salePrice()));enter(Step.SELL);
                }
                case SELL -> {
                    if(!sellDialogClicked&&tick-since>=6&&NativeDialogs.confirmSale(mc,item,pending.salePrice())){sellDialogClicked=true;since=tick;return;}
                    if(count(mc,pending.listing().key())==0&&InventoryEvidence.slotEpoch(handSlot)>receiptEpoch&&cursorEmpty(mc)) {
                        if(NativeDialogs.isDialog(mc.screen)) {if(!sellDialogClicked)return;mc.setScreen(null);}
                        enter(Step.RETURN_HAND);
                    }
                }
                case RETURN_HAND -> {
                    if(mc.screen!=null){if(mc.screen instanceof AbstractContainerScreen<?>)mc.player.closeContainer();return;}
                    if(restoreNeeded) {
                        var inv=mc.player.getInventory();
                        if(!inv.getItem(handSlot).isEmpty()||!ItemStack.isSameItemSameComponents(inv.getItem(swapIndex),displaced)||inv.getItem(swapIndex).getCount()!=displaced.getCount())
                            throw new IllegalStateException("Önceki hızlı erişim eşyası geri taşınamadı");
                        swapEpoch=InventoryEvidence.slotEpoch(handSlot);
                        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId,swapIndex,handSlot,ClickType.SWAP,mc.player);
                        enter(Step.RESTORE);
                    } else {restoreSelection(mc);checkingBefore=false;enter(Step.OWN_OPEN);}
                }
                case RESTORE -> {
                    var restored=mc.player.getInventory().getItem(handSlot);
                    if(InventoryEvidence.slotEpoch(handSlot)>swapEpoch&&ItemStack.isSameItemSameComponents(restored,displaced)&&restored.getCount()==displaced.getCount()){
                        restoreNeeded=false;restoreSelection(mc);checkingBefore=false;enter(Step.OWN_OPEN);
                    }
                }
                case PAUSE -> {if(tick-since>=40)enter(Step.OPEN);}
                case STOPPED -> {}
            }
        } catch(Exception error) {stop(error.getClass().getSimpleName()+": "+error.getMessage());}
    }

    private void scan(Minecraft mc) throws Exception {
        var menu=screen(mc).getMenu();List<Market.Listing> rows=new ArrayList<>();Map<Integer,PriceQuote> quotes=new HashMap<>();
        for(Slot slot:menu.slots) {
            if(slot.index>=45||slot.container==mc.player.getInventory()||!plain(slot.getItem()))continue;
            var q=quote(slot.getItem());if(q.isEmpty())continue;
            String id=BuiltInRegistries.ITEM.getKey(slot.getItem().getItem()).toString();
            rows.add(AutoPolicy.listing(slot.index,key(slot.getItem()),id,slot.getItem().getCount(),q.get()));quotes.put(slot.index,q.get());
        }
        long now = System.currentTimeMillis();
        scannedPages++;scannedListings+=rows.size();
        Map<String,OfficialMarket.Stats> history=official.stats(now);
        Map<String,Long> caps=new HashMap<>();web.prices(now).forEach((id,value)->caps.put(id,Market.toMinor(value)));
        var evaluation=OpportunityModel.evaluate(rows,target,remaining(),cfg.minNetMargin,fee(),cfg.undercut,cfg.minPeers,caps,history,now);
        List<Market.Deal> deals=evaluation.deals();lastStatus=evaluation.reason();
        offers.removeIf(o->now-o.seenMillis()>60_000||o.itemId().equals(target));
        for(var d:deals) {
            var l=d.listing();var s=history.get(l.itemId());
            String evidence=s==null?(caps.containsKey(l.itemId())?"Canli ilanlar + web referansi; talep bilinmiyor":"Yalniz canli ilan tahmini; tamamlanan satis ve talep bilinmiyor"):
                s.saleCount()+" gercek satis ornegi; "+String.format(Locale.ROOT,"%.2f",s.salesPerHour())+" ornek/saat; oynaklik %"+Math.round(s.volatilityPct());
            offers.add(new TraderDashboard.Offer(l.itemId(),l.count(),l.price(),d.salePrice(),d.netProfit(),evidence,now));
        }
        while(offers.size()>30)offers.removeFirst();
        var result=deals.stream().findFirst();
        if(result.isPresent()) {
            var d=result.get();var l=d.listing();
            if(count(mc,l.key())==0&&mc.player.getInventory().getFreeSlot()>=0&&cursorEmpty(mc)) {
                pending=d;item=menu.getSlot(l.slot()).getItem().copy();purchaseQuote=quotes.get(l.slot());
                if(!precheckedKey.equals(l.key())||precheckedCount!=l.count()||precheckedPrice!=d.salePrice()||tick-precheckedAt>1200){
                    checkingBefore=true;enter(Step.OWN_OPEN);return;
                }
                // Revalidate the exact visible item and conservative debit bounds immediately before the first click.
                var current=menu.getSlot(l.slot()).getItem();var currentQuote=quote(current);
                if(!key(current).equals(l.key())||current.getCount()!=l.count()||currentQuote.isEmpty()||!currentQuote.get().equals(purchaseQuote))return;
                ledger.reserve(l.price(),Market.toMinor(cfg.budget));ledger.unresolved="AUTO alış ayrıldı: "+target+" x"+l.count()+" azami="+Market.formatMinor(l.price());save();
                journal.event("Alis icin ayrildi: "+target+" x"+l.count()+" azami "+Market.formatMinor(l.price()));
                purchaseConfirmed=false;oldSelected=mc.player.getInventory().getSelectedSlot();
                receiptEpoch=InventoryEvidence.epoch();
                say("Fırsat: "+target+" x"+l.count()+" azami alış="+Market.formatMinor(l.price())+" hedef ilan="+Market.formatMinor(d.salePrice()));
                click(mc,l.slot(),0,ClickType.PICKUP);enter(Step.BUY);return;
            }
            lastStatus="Firsat var; ayni esya envanterde veya bos envanter yeri yok";
        }
        if(page<3&&menu.slots.size()>53&&menu.getSlot(53).getItem().getHoverName().getString().strip().equalsIgnoreCase("Next page")){
            expectedPage=++page;click(mc,53,0,ClickType.PICKUP);enter(Step.PAGE);return;
        }
        nextTarget();
    }
    private int ownMatches(Minecraft mc) {
        int matches=0;
        for(var slot:screen(mc).getMenu().slots){
            if(slot.index>=45||slot.container==mc.player.getInventory()||!key(slot.getItem()).equals(pending.listing().key())||slot.getItem().getCount()!=pending.listing().count())continue;
            if(checkingBefore){matches++;continue;}
            var q=quote(slot.getItem());
            if(q.isPresent()&&q.get().containsExact(pending.salePrice())
                    && (sellDialogClicked || q.get().lowerMinor()==q.get().upperMinor()))matches++;
        }
        return matches;
    }
    private void prepareHand(Minecraft mc) {
        if(!purchaseConfirmed)throw new IllegalStateException("Alış onayı doğrulanmadı");
        if(mc.screen!=null){if(mc.screen instanceof AbstractContainerScreen<?>)mc.player.closeContainer();return;}
        if(!cursorEmpty(mc))return;
        var inventory=mc.player.getInventory();int index=-1;
        for(int i=0;i<36;i++)if(key(inventory.getItem(i)).equals(pending.listing().key())&&inventory.getItem(i).getCount()==pending.listing().count()){index=i;break;}
        if(index<0)throw new IllegalStateException("Teslim edilen tam yığın bulunamadı");
        restoreNeeded=false;swapIndex=-1;displaced=ItemStack.EMPTY;
        if(index<9){handSlot=index;select(mc,handSlot);enter(Step.READY);return;}
        handSlot=oldSelected;
        for(int i=0;i<9;i++)if(inventory.getItem(i).isEmpty()){handSlot=i;break;}
        displaced=inventory.getItem(handSlot).copy();restoreNeeded=!displaced.isEmpty();swapIndex=index;
        swapEpoch=InventoryEvidence.slotEpoch(handSlot);
        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId,index,handSlot,ClickType.SWAP,mc.player);enter(Step.SWAP);
    }
    private boolean deliveryProven(Minecraft mc) {
        if(!cursorEmpty(mc)||count(mc,pending.listing().key())!=pending.listing().count())return false;
        for(int i=0;i<36;i++)if(key(mc.player.getInventory().getItem(i)).equals(pending.listing().key())&&InventoryEvidence.slotEpoch(i)>receiptEpoch)return true;
        return false;
    }
    private static void select(Minecraft mc,int slot) {mc.player.getInventory().setSelectedSlot(slot);mc.player.connection.send(new ServerboundSetCarriedItemPacket(slot));}
    private void restoreSelection(Minecraft mc) {if(mc.player!=null&&oldSelected>=0&&oldSelected<9)select(mc,oldSelected);}
}

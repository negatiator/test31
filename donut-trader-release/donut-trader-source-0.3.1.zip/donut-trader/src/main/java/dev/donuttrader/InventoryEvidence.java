package dev.donuttrader;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

/** Monotonic server-inventory receipts, never advanced by a local optimistic click. */
public final class InventoryEvidence {
    private InventoryEvidence() {}
    private static final AtomicLong EPOCH = new AtomicLong();
    private static final AtomicLongArray SLOT_EPOCHS = new AtomicLongArray(36);
    public static long epoch() { return EPOCH.get(); }
    public static long slotEpoch(int inventorySlot) {
        return inventorySlot >= 0 && inventorySlot < 36 ? SLOT_EPOCHS.get(inventorySlot) : -1;
    }
    public static void note() { EPOCH.incrementAndGet(); }
    public static void noteSlot(int inventorySlot) {
        if (inventorySlot < 0 || inventorySlot >= 36) return;
        SLOT_EPOCHS.set(inventorySlot, EPOCH.incrementAndGet());
    }
    public static void noteContent(int itemCount) {
        long event = EPOCH.incrementAndGet();
        for (int menuSlot = 9; menuSlot < Math.min(45, itemCount); menuSlot++)
            SLOT_EPOCHS.set(menuSlot >= 36 ? menuSlot - 36 : menuSlot, event);
    }
    public static void noteContainerSlot(int containerId, int menuSlot) {
        if (containerId == -2) noteSlot(menuSlot);
        else if (containerId == 0 && menuSlot >= 9 && menuSlot < 45) noteSlot(menuSlot >= 36 ? menuSlot - 36 : menuSlot);
    }
    /** The observer resolves the actual Slot's owning container and index; no chest-size offset is inferred. */
    public static void noteMappedSlot(int packetContainerId, int activeContainerId,
                                      boolean playerInventory, int inventorySlot) {
        if (packetContainerId > 0 && packetContainerId == activeContainerId && playerInventory)
            noteSlot(inventorySlot);
    }
}

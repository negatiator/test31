package dev.donuttrader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Local audit history. A relist is never recorded as a completed sale. */
public final class TradingJournal {
    public record Entry(long atMillis, String message, long cumulativeEstimatedProfitMinor) {}
    private record Saved(int version, int listings, long estimatedProfitMinor, List<Entry> entries) {}
    private final Path file;
    private final List<Entry> entries = new ArrayList<>();
    private int listings;
    private long estimatedProfit;
    private String storageStatus = "";

    public TradingJournal(Path file) {
        this.file = file;
        if (!Files.exists(file)) return;
        try {
            if (Files.size(file) > 1_000_000) throw new IOException("History too large");
            Saved saved = new Gson().fromJson(Files.readString(file), Saved.class);
            if (saved == null || saved.version != 1 || saved.listings < 0 || saved.estimatedProfitMinor < 0
                    || saved.entries == null || saved.entries.size() > 200) throw new IOException("Invalid history");
            long now = System.currentTimeMillis();
            for (Entry e : saved.entries) {
                if (e == null || e.atMillis <= 0 || e.atMillis > now + 60_000 || e.message == null
                        || e.message.length() > 600 || e.cumulativeEstimatedProfitMinor < 0)
                    throw new IOException("Invalid history entry");
            }
            entries.addAll(saved.entries); listings = saved.listings; estimatedProfit = saved.estimatedProfitMinor;
        } catch (Exception invalid) { storageStatus = "Gecmis okunamadi; butce defteri korunuyor"; }
    }
    public synchronized void event(String message) {
        entries.add(new Entry(System.currentTimeMillis(), message.substring(0, Math.min(message.length(), 600)), estimatedProfit));
        while (entries.size() > 200) entries.removeFirst();
        persist();
    }
    public synchronized void listed(String itemId, int count, long buy, long target, long netEstimate) {
        listings = Math.addExact(listings, 1);
        estimatedProfit = Math.addExact(estimatedProfit, Math.max(0, netEstimate));
        event("Ilan dogrulandi: " + itemId + " x" + count + " | ayrilan " + Market.formatMinor(buy)
                + " | hedef " + Market.formatMinor(target) + " | tahmini net " + Market.formatMinor(netEstimate));
    }
    private void persist() {
        Path temporary = null;
        try {
            Files.createDirectories(file.getParent());
            temporary = Files.createTempFile(file.getParent(), "donut-history-", ".tmp");
            Files.writeString(temporary, new GsonBuilder().setPrettyPrinting().create()
                    .toJson(new Saved(1, listings, estimatedProfit, List.copyOf(entries))));
            Files.move(temporary, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            storageStatus = "";
        } catch (IOException failure) { storageStatus = "Gecmis kaydedilemedi; butce defteri ayri korunur"; }
        finally { if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) {} }
    }
    public synchronized List<Entry> entries() { return List.copyOf(entries); }
    public synchronized int listings() { return listings; }
    public synchronized long estimatedProfitMinor() { return estimatedProfit; }
    public synchronized String storageStatus() { return storageStatus; }
}

package dev.donuttrader;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Pure validation of the monetary evidence displayed by a native confirmation dialog. */
public final class NativeDialogProof {
    private NativeDialogProof() {}
    private static final Pattern MONEY = Pattern.compile("(?i)\\$\\s*([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]+)?)(?:\\s*([kmb]))?(?![A-Za-z0-9,]|\\.[0-9])");
    public record Range(long minMinor, long maxMinor) {
        public Range {
            if (minMinor <= 0 || maxMinor < minMinor) throw new IllegalArgumentException("Invalid displayed amount");
        }
        public boolean within(long minimum, long maximum) { return minMinor >= minimum && maxMinor <= maximum; }
    }
    public static Optional<Range> totalWithin(String text, long minimum, long maximum) {
        if (minimum <= 0 || maximum < minimum) return Optional.empty();
        Matcher matcher = MONEY.matcher(stripFormatting(text));
        Set<Range> values = new HashSet<>();
        while (matcher.find()) {
            try {
                BigDecimal displayed = new BigDecimal(matcher.group(1).replace(",", ""));
                String suffix = matcher.group(2);
                long multiplier = suffix == null ? 1 : switch (suffix.toLowerCase(Locale.ROOT)) {
                    case "k" -> 1_000L; case "m" -> 1_000_000L; case "b" -> 1_000_000_000L;
                    default -> throw new IllegalArgumentException("Unknown suffix");
                };
                BigDecimal unit = BigDecimal.valueOf(multiplier).movePointRight(2);
                long low = displayed.multiply(unit).longValueExact();
                long high = suffix == null ? low : Math.addExact(low,
                        unit.movePointLeft(displayed.scale()).setScale(0, RoundingMode.CEILING).longValueExact() - 1);
                values.add(new Range(low, high));
            } catch (ArithmeticException | IllegalArgumentException invalid) { return Optional.empty(); }
        }
        // Repeated display of the same amount is fine. Distinct prices, balances, or fees need
        // a schema-specific proof rather than guessing which monetary value is the total.
        if (values.size() != 1) return Optional.empty();
        Range value = values.iterator().next();
        return value.within(minimum, maximum) ? Optional.of(value) : Optional.empty();
    }
    public static String stripFormatting(String text) {
        return text == null ? "" : text.replaceAll("§.", "").replace('\u00a0', ' ').strip();
    }
    public static String label(String text) {
        return Normalizer.normalize(stripFormatting(text), Normalizer.Form.NFKD).replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").strip();
    }
    /** Text-only fallback requires an explicit count and the complete vanilla name in an action/item clause. */
    public static boolean requireTextItem(String text, String vanillaName, int count) {
        if (count <= 0 || vanillaName == null || vanillaName.isBlank()) return false;
        String cleaned = Normalizer.normalize(stripFormatting(text), Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        String name = label(vanillaName);
        if (name.isBlank()) return false;
        String words = Arrays.stream(name.split(" +")).map(Pattern::quote).collect(java.util.stream.Collectors.joining("\\s+"));
        String start = "(?:^|[\\r\\n]|\\b(?:buy|buying|purchase|purchasing|sell|selling|list|listing|receive|receiving|item|items)(?:\\s+of)?\\s*:?\\s+)";
        String end = "(?=\\s*(?:$|[\\r\\n.!?;,]|\\$|\\b(?:for|at|cost|costs|price|total)\\b))";
        String amountFirst = count + "\\s*(?:x\\s*)?" + words;
        String nameFirst = words + "\\s+x\\s*" + count;
        return Pattern.compile("(?i)" + start + "(?:" + amountFirst + "|" + nameFirst + ")" + end).matcher(cleaned).find();
    }
}

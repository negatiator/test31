package dev.donuttrader;

import java.util.*;

public final class AutoPolicy {
    private AutoPolicy() {}
    public static final List<String> WATCH = List.of("diamond", "iron_ingot", "gold_ingot", "emerald", "golden_apple",
        "totem_of_undying", "obsidian", "experience_bottle", "ancient_debris", "netherite_scrap", "netherite_ingot",
        "gunpowder", "quartz", "sea_pickle", "coal", "redstone", "ender_pearl", "lapis_lazuli",
        "iron_block", "gold_block", "diamond_block");
    public static boolean ownListingProven(int before, int after) { return before == 0 && after == 1; }
    public static boolean serverSwapProven(long before, long after, boolean exactHeldItem) {
        return after > before && exactHeldItem;
    }
    public static Market.Listing listing(int slot, String key, String id, int count, PriceQuote quote) {
        return new Market.Listing(slot, key, id, count, quote.upperMinor(), quote.lowerMinor());
    }
}

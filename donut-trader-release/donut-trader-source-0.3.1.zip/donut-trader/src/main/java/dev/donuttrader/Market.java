package dev.donuttrader;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.regex.*;
import dev.doughbay.core.stats.RobustStats;

/** No Minecraft dependencies: pricing can be verified independently of the client. */
public final class Market {
    private Market() {}
    private static final Pattern MONEY = Pattern.compile("(?i)^\\$?([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]+)?)\\s*([kmb]?)$");
    private static BigDecimal decimalMoney(String input) {
        Matcher m = MONEY.matcher(input.trim());
        if (!m.matches()) throw new IllegalArgumentException("Invalid money: " + input);
        long multiplier = switch (m.group(2).toLowerCase(Locale.ROOT)) {
            case "k" -> 1_000L; case "m" -> 1_000_000L; case "b" -> 1_000_000_000L; default -> 1;
        };
        return new BigDecimal(m.group(1).replace(",", "")).multiply(BigDecimal.valueOf(multiplier));
    }
    public static long money(String input) { return decimalMoney(input).longValueExact(); }
    public static long moneyMinor(String input) { return decimalMoney(input).movePointRight(2).longValueExact(); }
    public static long toMinor(long coins) { return Math.multiplyExact(coins, 100); }
    public static String formatMinor(long amount) { return BigDecimal.valueOf(amount, 2).stripTrailingZeros().toPlainString(); }
    /** Listing, deal, budget and reference amounts passed to the engine use minor units (0.01 coin). */
    public record Listing(int slot, String key, String itemId, int count, long price, long referencePrice) {
        public Listing(int slot, String key, String itemId, int count, long price) { this(slot, key, itemId, count, price, price); }
    }
    public record Deal(Listing listing, long salePrice, long netProfit) {}

    /** A completed-sale reference can price an exact vanilla commodity without inventing live peer rows. */
    public static Optional<Deal> fromReference(Listing listing, long unitReference,
            double margin, double fee, double undercut) {
        if (listing.price() <= 0 || listing.count() <= 0) return Optional.empty();
        return capBySales(new Deal(listing, Long.MAX_VALUE, 0), unitReference, margin, fee, undercut);
    }

    /** A completed-sales cap can lower an asking-price estimate, never raise it. */
    public static Optional<Deal> capBySales(Deal deal, long unitReference, double margin, double fee, double undercut) {
        if (unitReference <= 0 || !Double.isFinite(margin) || margin < 0 || !Double.isFinite(fee) || fee < 0 || fee >= 1
                || !Double.isFinite(undercut) || undercut < 0 || undercut >= 1) return Optional.empty();
        var l = deal.listing();
        var cap = BigDecimal.valueOf(unitReference).multiply(BigDecimal.valueOf(l.count())).multiply(BigDecimal.valueOf(1 - undercut));
        long sale = cap.min(BigDecimal.valueOf(deal.salePrice())).setScale(0, RoundingMode.FLOOR).longValueExact();
        long net = BigDecimal.valueOf(sale).multiply(BigDecimal.valueOf(1 - fee)).setScale(0, RoundingMode.FLOOR).longValueExact();
        long profit = net - l.price();
        return profit > 0 && BigDecimal.valueOf(profit).compareTo(BigDecimal.valueOf(l.price()).multiply(BigDecimal.valueOf(margin))) >= 0
                ? Optional.of(new Deal(l, sale, profit)) : Optional.empty();
    }

    public static Optional<Deal> best(List<Listing> listings, Set<String> allowed,
            long remaining, double margin, double fee, double undercut, int minPeers) {
        return best(listings, allowed, remaining, margin, fee, undercut, minPeers, null);
    }
    public static Optional<Deal> best(List<Listing> listings, Set<String> allowed,
            long remaining, double margin, double fee, double undercut, int minPeers, Map<String, Long> salesCaps) {
        return deals(listings, allowed, remaining, margin, fee, undercut, minPeers, salesCaps).stream().findFirst();
    }
    public static List<Deal> deals(List<Listing> listings, Set<String> allowed,
            long remaining, double margin, double fee, double undercut, int minPeers, Map<String, Long> salesCaps) {
        if (remaining < 0 || !Double.isFinite(margin) || margin < 0 || !Double.isFinite(fee)
                || fee < 0 || fee >= 1 || !Double.isFinite(undercut) || undercut < 0 || undercut >= 1 || minPeers < 3)
            throw new IllegalArgumentException("Invalid trading limits");
        return listings.stream().filter(l -> allowed.contains(l.itemId()) && l.count() > 0 && l.price() > 0 && l.price() <= remaining)
            .map(l -> evaluate(l, listings, margin, fee, undercut, minPeers)
                .flatMap(d -> salesCaps == null ? Optional.of(d)
                    : capBySales(d, salesCaps.getOrDefault(l.itemId(), 0L), margin, fee, undercut)))
            .flatMap(Optional::stream).sorted(Comparator.comparingLong(Deal::netProfit).reversed()).toList();
    }
    private static Optional<Deal> evaluate(Listing l, List<Listing> all, double margin, double fee, double undercut, int minPeers) {
        // Compare complete, equal-sized stacks with identical components; exclude the target itself.
        var peers = all.stream().filter(p -> p.slot() != l.slot() && p.key().equals(l.key())
                && p.count() == l.count() && p.referencePrice() > 0).map(Listing::referencePrice).sorted().toList();
        if (peers.size() < minPeers) return Optional.empty();
        if (peerScatter(peers) > .30) return Optional.empty();
        long reference = peers.get((peers.size() - 1) / 4); // lower quartile, not optimistic maximum
        long sale = BigDecimal.valueOf(reference).multiply(BigDecimal.valueOf(1 - undercut))
                .setScale(0, RoundingMode.FLOOR).longValueExact();
        long net = BigDecimal.valueOf(sale).multiply(BigDecimal.valueOf(1 - fee))
                .setScale(0, RoundingMode.FLOOR).longValueExact();
        long profit = net - l.price();
        boolean enough = BigDecimal.valueOf(profit).compareTo(BigDecimal.valueOf(l.price()).multiply(BigDecimal.valueOf(margin))) >= 0;
        return enough && profit > 0 ? Optional.of(new Deal(l, sale, profit)) : Optional.empty();
    }
    /** Gonuts' robust log MAD plus quartile spread: a broad live book is not stable resale evidence. */
    public static double peerScatter(List<Long> sortedPrices) {
        if(sortedPrices.size()<3)return 0;
        var values=sortedPrices.stream().filter(p->p>0).map(Long::doubleValue).sorted().toList();
        if(values.size()<3)return 0;
        double mad=RobustStats.robustLogVolatility(values);
        double p25=values.get((values.size()-1)/4),p75=values.get(3*(values.size()-1)/4);
        double spread=Math.expm1(Math.log(p75/p25)/1.349);
        return Math.max(Double.isFinite(mad)?mad:0,Double.isFinite(spread)?spread:1);
    }
}

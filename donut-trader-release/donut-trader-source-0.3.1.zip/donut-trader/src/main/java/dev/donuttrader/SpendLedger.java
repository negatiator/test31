package dev.donuttrader;

/** Existing whole-coin ledgers migrate once; no migration frees previously reserved budget. */
public final class SpendLedger {
    public int currencyScale; // Missing/0: legacy coins; 2: minor units.
    public long committed;
    public String unresolved = "";
    public boolean upgrade() {
        if (committed < 0 || unresolved == null) throw new IllegalArgumentException("Invalid ledger");
        if (currencyScale == 2) return false;
        if (currencyScale != 0) throw new IllegalArgumentException("Unknown ledger currency scale");
        committed = Market.toMinor(committed);
        currencyScale = 2;
        return true;
    }
    public void reserve(long cost, long budgetMinor) {
        if (currencyScale != 2 || cost <= 0 || budgetMinor < 0 || committed > budgetMinor || cost > budgetMinor - committed)
            throw new IllegalArgumentException("Purchase exceeds remaining budget");
        committed = Math.addExact(committed, cost);
    }
}

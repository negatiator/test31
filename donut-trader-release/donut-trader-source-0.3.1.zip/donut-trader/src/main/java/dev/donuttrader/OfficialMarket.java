package dev.donuttrader;

import com.google.gson.*;
import dev.doughbay.core.stats.RobustStats;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Optional, read-only completed-sales evidence. No credential means no fabricated data. */
public final class OfficialMarket {
    public static final String SOURCE = "https://api.donutsmp.net/v1/auction/transactions/";
    public static final long HISTORY_MS = 3 * 24 * 60 * 60 * 1000L;
    public static final long FRESH_MS = 6 * 60 * 60 * 1000L;
    private static final long POLL_MS = 30_000;
    private static final int MAX_BYTES = 4 * 1024 * 1024, MAX_SALES = 10_000;
    private static final Set<String> ITEMS = Set.of(
            "diamond", "iron_ingot", "gold_ingot", "emerald", "golden_apple", "totem_of_undying",
            "obsidian", "experience_bottle", "ancient_debris", "netherite_scrap", "netherite_ingot",
            "gunpowder", "quartz", "sea_pickle", "coal", "redstone", "ender_pearl", "lapis_lazuli",
            "diamond_block", "iron_block", "gold_block", "emerald_block", "redstone_block", "coal_block",
            "lapis_block", "netherite_block", "raw_iron", "raw_gold", "raw_copper", "copper_ingot",
            "copper_block", "stone", "cobblestone", "deepslate", "sand", "gravel", "glass",
            "oak_log", "spruce_log", "jungle_log", "spruce_slab", "packed_ice", "ice", "blue_ice",
            "wheat", "carrot", "potato", "bread", "apple", "cooked_beef", "cooked_porkchop",
            "cooked_chicken", "sugar_cane", "bamboo", "kelp", "dried_kelp_block", "cactus",
            "bone", "bone_meal", "string", "leather", "slime_ball", "blaze_rod", "blaze_powder");
    private static final Set<String> ITEM_FIELDS = Set.of("id", "count", "display_name", "lore", "contents", "enchants");
    private static final Map<String, String> SPECIAL_NAMES = Map.of(
            "experience_bottle", "Bottle o' Enchanting", "redstone", "Redstone Dust",
            "cooked_beef", "Steak", "slime_ball", "Slimeball");

    public record Stats(String itemId, long unitMinor, int saleCount, long units,
                        long newestSaleMillis, double salesPerHour, double volatilityPct) {}
    public record Sale(String itemId, int count, long totalMinor, String seller, long soldMillis) {
        public Sale {
            if (itemId == null || !itemId.startsWith("minecraft:")
                    || !ITEMS.contains(itemId.substring(10)) || count < 1 || count > 64
                    || totalMinor < 1 || totalMinor > 100_000_000_000_000L
                    || seller == null || seller.isBlank() || seller.length() > 80 || soldMillis < 1)
                throw new IllegalArgumentException("Invalid completed sale");
        }
        private BigDecimal unit() {
            return BigDecimal.valueOf(totalMinor).divide(BigDecimal.valueOf(count), 20, RoundingMode.FLOOR);
        }
    }

    private record Cache(long computedAt, Map<String,Stats> stats) {}
    private record Saved(int version,String source,List<Sale> sales) {}
    private final Path keyFile, legacyKeyFile, historyFile;
    private final AtomicBoolean inFlight = new AtomicBoolean();
    private volatile String apiKey = "", message = "API anahtarı yok; gerçekleşmiş satış verisi yok";
    private volatile List<Sale> sales = List.of();
    private volatile Cache cache = new Cache(0,Map.of());
    private volatile long lastSuccess;
    private volatile boolean authenticationFailed;
    private long nextAttempt, generation;
    private int page = 1;

    public OfficialMarket(Path configDir) {
        keyFile = configDir.resolve("donut-trader-api-key.txt");
        legacyKeyFile = configDir.resolve("donut-flip-scanner").resolve("api-key.txt");
        historyFile = configDir.resolve("donut-trader-sales.json");
        Path selected = Files.exists(keyFile) ? keyFile : legacyKeyFile;
        if (Files.exists(selected)) {
            try {
                if (Files.size(selected) > 1_024) throw new IOException("Invalid credential file");
                apiKey = validKey(Files.readString(selected));
                if (!apiKey.isEmpty()) message = "Gerçekleşmiş satış API bağlantısı bekleniyor";
            } catch (IOException | IllegalArgumentException invalid) {
                message = "API anahtarı dosyası okunamadı veya geçersiz";
            }
        }
        if(hasKey()&&Files.exists(historyFile))try {
            if(Files.size(historyFile)>MAX_BYTES)throw new IOException("History too large");
            Saved saved=new Gson().fromJson(Files.readString(historyFile),Saved.class);
            if(saved==null||saved.version!=1||!SOURCE.equals(saved.source)||saved.sales==null||saved.sales.size()>MAX_SALES)
                throw new IOException("Invalid sales history");
            sales=boundedUnique(saved.sales,System.currentTimeMillis());
            // Disk history warms the next successful API response; it never activates trades by itself.
        }catch(Exception invalid){sales=List.of();}
    }
    public boolean hasKey() { return !apiKey.isEmpty(); }

    /** The key is local only; errors and status messages never include its value. */
    public synchronized void setKey(String raw) throws IOException {
        String key = validKey(raw);
        Files.createDirectories(keyFile.getParent());
        Path temp = Files.createTempFile(keyFile.getParent(), "donut-key-", ".tmp");
        try {
            try { Files.setPosixFilePermissions(temp, PosixFilePermissions.fromString("rw-------")); }
            catch (UnsupportedOperationException ignored) { /* Windows uses its inherited file ACL. */ }
            Files.writeString(temp, key, StandardCharsets.UTF_8);
            Files.move(temp, keyFile, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(temp); }
        apiKey = key; generation++; page = 1; nextAttempt = 0;
        sales = List.of(); lastSuccess = 0; authenticationFailed = false;
        cache = new Cache(0,Map.of());
        message = key.isEmpty() ? "API anahtarı yok; gerçekleşmiş satış verisi yok" : "Gerçekleşmiş satış API bağlantısı bekleniyor";
    }
    private static String validKey(String raw) {
        if (raw == null) throw new IllegalArgumentException("API anahtarı geçersiz");
        String value = raw.strip();
        if (value.regionMatches(true, 0, "Bearer ", 0, 7)) value = value.substring(7).strip();
        if (value.length() > 512 || value.chars().anyMatch(c -> c < 33 || c > 126))
            throw new IllegalArgumentException("API anahtarı geçersiz");
        return value;
    }

    public Map<String, Stats> stats(long now) {
        Cache current=cache;
        if(!hasKey()||authenticationFailed||now<current.computedAt||now-current.computedAt>90_000)return Map.of();
        Map<String,Stats> fresh=new HashMap<>();
        current.stats.forEach((id,s)->{if(now>=s.newestSaleMillis&&now-s.newestSaleMillis<=FRESH_MS)fresh.put(id,s);});
        return Map.copyOf(fresh);
    }
    public String status(long now) {
        String age = lastSuccess == 0 ? "" : "; son başarılı okuma=" + Math.max(0, now - lastSuccess) / 1000 + " sn";
        return "Resmî satış API: " + message + "; yeterli örnekli eşya=" + stats(now).size()
                + "; örneklenen satış=" + sales.size() + age;
    }

    /** At most one read-only page request per 30 seconds; no render-thread I/O. */
    public synchronized void refresh(long now) {
        if (!hasKey() || now < nextAttempt || !inFlight.compareAndSet(false, true)) return;
        nextAttempt = now + POLL_MS;
        String key = apiKey; long version = generation; int requestedPage = page;
        Thread.ofPlatform().daemon().name("donut-trader-sales").start(() -> {
            try (HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8))
                    .followRedirects(HttpClient.Redirect.NEVER).build()) {
                HttpRequest request = HttpRequest.newBuilder(URI.create(SOURCE + requestedPage))
                        .timeout(Duration.ofSeconds(15)).header("Authorization", "Bearer " + key)
                        .header("Accept", "application/json").header("User-Agent", "DonutTrader/0.3 (completed-sale evidence)").GET().build();
                HttpResponse<java.io.InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
                try (var body = response.body()) {
                    int code = response.statusCode(); long receivedAt = System.currentTimeMillis();
                    if (code == 401 || code == 403) {
                        updateFailure(version, "Anahtar reddedildi (HTTP " + code + ")", receivedAt + 15 * 60_000L, true);
                    } else if (code == 429) {
                        long wait = retryDelay(response.headers().firstValue("Retry-After").orElse(""), receivedAt);
                        updateFailure(version, "İstek sınırı; bekleniyor (HTTP 429)", receivedAt + wait, false);
                    } else if (code != 200) {
                        updateFailure(version, "Geçici HTTP hatası " + code, receivedAt + 60_000, false);
                    } else {
                        long declared = response.headers().firstValueAsLong("Content-Length").orElse(0);
                        if (declared > MAX_BYTES) throw new IOException("Response too large");
                        byte[] bytes = body.readNBytes(MAX_BYTES + 1);
                        if (bytes.length > MAX_BYTES) throw new IOException("Response too large");
                        List<Sale> incoming = parseSales(new String(bytes, StandardCharsets.UTF_8), receivedAt);
                        List<Sale> combined;
                        synchronized(this) {
                            if(generation!=version)return;
                            combined=new ArrayList<>(sales);combined.addAll(incoming);
                        }
                        List<Sale> bounded=boundedUnique(combined,receivedAt);
                        Map<String,Stats> computed=summarize(bounded,receivedAt);
                        synchronized (this) {
                            if (generation == version) {
                                sales=bounded;cache=new Cache(receivedAt,computed);lastSuccess=receivedAt;
                                authenticationFailed = false;
                                page = requestedPage == 10 ? 1 : requestedPage + 1;
                                message = "Bağlı; gerçek tamamlanmış satış örnekleri";
                            }
                        }
                        persistHistory(bounded);
                    }
                }
            } catch (Exception failure) {
                updateFailure(version, "Bağlantı veya satış şeması hatası; tekrar beklenecek", System.currentTimeMillis() + 60_000, false);
            } finally { inFlight.set(false); }
        });
    }
    private synchronized void updateFailure(long version, String description, long retryAt, boolean denied) {
        if (generation != version) return;
        message = description; nextAttempt = Math.max(nextAttempt, retryAt);
        if (denied) { authenticationFailed = true; sales = List.of();cache=new Cache(0,Map.of()); }
    }
    public static long retryDelay(String value, long now) {
        long delay = 120_000;
        try {
            delay = Math.multiplyExact(Long.parseLong(value.strip()), 1000);
        } catch (RuntimeException notSeconds) {
            try { delay = ZonedDateTime.parse(value, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() - now; }
            catch (RuntimeException notDate) { /* Use bounded default. */ }
        }
        return Math.max(POLL_MS, Math.min(30 * 60_000L, delay));
    }

    public static List<Sale> parseSales(String json, long now) {
        validateJsonBounds(json);
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        long status = integer(root.get("status"));
        if (status < 200 || status >= 300 || !root.has("result") || !root.get("result").isJsonArray())
            throw new IllegalArgumentException("Invalid completed-sales response");
        JsonArray rows = root.getAsJsonArray("result");
        if (rows.size() > 1_000) throw new IllegalArgumentException("Too many completed-sales rows");
        List<Sale> result = new ArrayList<>();
        for (JsonElement row : rows) {
            try {
                JsonObject sale = row.getAsJsonObject(), item = sale.getAsJsonObject("item");
                if (!ITEM_FIELDS.containsAll(item.keySet())) continue;
                String id = string(item.get("id"));
                if (!id.startsWith("minecraft:") || !ITEMS.contains(id.substring(10))) continue;
                String path = id.substring(10);
                int count = Math.toIntExact(integer(item.get("count")));
                if (count < 1 || count > 64 || (path.equals("totem_of_undying") && count != 1)
                        || (path.equals("ender_pearl") && count > 16)) continue;
                if (!emptyArray(item.get("lore")) || !emptyArray(item.get("contents")) || !plainEnchants(item.get("enchants"))) continue;
                if (item.has("display_name") && !item.get("display_name").isJsonNull()) {
                    String name = string(item.get("display_name"));
                    String expected = SPECIAL_NAMES.getOrDefault(path, path.replace('_', ' '));
                    if (!name.isEmpty() && !name.equalsIgnoreCase(expected)) continue;
                }
                long amount = decimal(sale.get("price")).movePointRight(2).longValueExact();
                long sold = timestamp(sale.get("unixMillisDateSold"));
                if (sold > now || now - sold > HISTORY_MS) continue;
                JsonObject sellerObject = sale.getAsJsonObject("seller");
                String seller = "";
                if (sellerObject.has("uuid") && !sellerObject.get("uuid").isJsonNull()) {
                    String uuid = string(sellerObject.get("uuid"));
                    if (uuid.matches("(?i)(?:[0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})")) seller = "uuid:" + uuid.replace("-", "").toLowerCase(Locale.ROOT);
                }
                if (seller.isEmpty() && sellerObject.has("name") && !sellerObject.get("name").isJsonNull()) {
                    String name = string(sellerObject.get("name"));
                    if (name.matches("[A-Za-z0-9_]{1,16}")) seller = "name:" + name.toLowerCase(Locale.ROOT);
                }
                result.add(new Sale(id, count, amount, seller, sold));
            } catch (RuntimeException invalidRow) { /* Unknown or customized rows cannot become vanilla-price evidence. */ }
        }
        return boundedUnique(result, now);
    }
    private static boolean emptyArray(JsonElement value) {
        return value == null || value.isJsonNull() || value.isJsonArray() && value.getAsJsonArray().isEmpty();
    }
    private static boolean plainEnchants(JsonElement value) {
        if (value == null || value.isJsonNull()) return true;
        if (!value.isJsonObject()) return false;
        JsonObject object = value.getAsJsonObject();
        if (!Set.of("enchantments", "trim").containsAll(object.keySet())) return false;
        for (var entry : object.entrySet()) {
            if (entry.getValue().isJsonNull()) continue;
            if (!entry.getValue().isJsonObject()) return false;
            JsonObject details = entry.getValue().getAsJsonObject();
            if (entry.getKey().equals("enchantments")) {
                if (!Set.of("levels").containsAll(details.keySet())) return false;
                JsonElement levels = details.get("levels");
                if (levels != null && !levels.isJsonNull() && (!levels.isJsonObject() || !levels.getAsJsonObject().isEmpty())) return false;
            } else {
                if (!Set.of("material", "pattern").containsAll(details.keySet())) return false;
                for (JsonElement v : details.asMap().values()) if (!v.isJsonNull() && (!v.isJsonPrimitive() || !v.getAsJsonPrimitive().isString() || !v.getAsString().isEmpty())) return false;
            }
        }
        return true;
    }
    private static String string(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString() || e.getAsString().length() > 256)
            throw new IllegalArgumentException("Invalid string");
        return e.getAsString();
    }
    private static BigDecimal decimal(JsonElement e) {
        if (e == null || !e.isJsonPrimitive())throw new IllegalArgumentException("Invalid decimal");
        var p=e.getAsJsonPrimitive();
        if(!p.isNumber()&&!p.isString())throw new IllegalArgumentException("Invalid decimal");
        String text=p.getAsString();
        if(!text.matches("[0-9]{1,18}(?:\\.[0-9]{1,8})?"))throw new IllegalArgumentException("Invalid decimal");
        return new BigDecimal(text);
    }
    private static long integer(JsonElement e) { return decimal(e).longValueExact(); }
    private static long timestamp(JsonElement e) {
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isString()) {
            String value = e.getAsString();
            if (!value.matches("[0-9]{1,15}")) throw new IllegalArgumentException("Invalid timestamp");
            return Long.parseLong(value);
        }
        return integer(e);
    }
    private static void validateJsonBounds(String json) {
        if (json == null || json.isBlank() || json.length() > MAX_BYTES) throw new IllegalArgumentException("Invalid JSON size");
        boolean quoted = false, escaped = false; int depth = 0;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (quoted) { if (escaped) escaped = false; else if (c == '\\') escaped = true; else if (c == '"') quoted = false; }
            else if (c == '"') quoted = true;
            else if (c == '{' || c == '[') { if (++depth > 24) throw new IllegalArgumentException("JSON too deep"); }
            else if (c == '}' || c == ']') depth--;
        }
    }
    private static List<Sale> boundedUnique(Collection<Sale> source, long now) {
        return source.stream().filter(s -> s.soldMillis() <= now && now - s.soldMillis() <= HISTORY_MS)
                .distinct().sorted(Comparator.comparingLong(Sale::soldMillis).reversed()).limit(MAX_SALES).toList();
    }
    public static Map<String, Stats> summarize(Collection<Sale> source, long now) {
        Map<String, List<Sale>> groups = new HashMap<>();
        for (Sale sale : boundedUnique(source, now)) groups.computeIfAbsent(sale.itemId(), ignored -> new ArrayList<>()).add(sale);
        Map<String, Stats> result = new HashMap<>();
        for (var entry : groups.entrySet()) {
            List<Sale> group = RobustStats.splitOutliersByLogPrice(entry.getValue(),s->s.unit().doubleValue()).kept();
            if (group.size() < 5 || now - group.getFirst().soldMillis() > FRESH_MS) continue;
            if(group.stream().map(Sale::seller).distinct().count()<3)continue;
            List<Sale> sorted = group.stream().sorted(Comparator.comparing(Sale::unit)).toList();
            double position = (sorted.size() - 1) * .4;
            int low = (int) Math.floor(position), high = (int) Math.ceil(position);
            BigDecimal p40 = sorted.get(low).unit().add(sorted.get(high).unit().subtract(sorted.get(low).unit())
                    .multiply(BigDecimal.valueOf(position - low)));
            double totalWeight = group.stream().mapToDouble(s -> Math.exp(-(now - s.soldMillis()) / (double) (24 * 60 * 60 * 1000L))).sum();
            double cumulative = 0; BigDecimal weightedMedian = sorted.getLast().unit();
            for (Sale sale : sorted) {
                cumulative += Math.exp(-(now - sale.soldMillis()) / (double) (24 * 60 * 60 * 1000L));
                if (cumulative >= totalWeight / 2) { weightedMedian = sale.unit(); break; }
            }
            long conservative = p40.min(weightedMedian).setScale(0, RoundingMode.FLOOR).longValueExact();
            if (conservative < 1) continue;
            long units = group.stream().mapToLong(Sale::count).sum();
            double robust=RobustStats.robustLogVolatility(group.stream().map(s->s.unit().doubleValue()).toList());
            double p25=sorted.get((sorted.size()-1)/4).unit().doubleValue();
            double p75=sorted.get(3*(sorted.size()-1)/4).unit().doubleValue();
            double spread=Math.expm1(Math.log(p75/p25)/1.349);
            double volatility=Math.max(Double.isFinite(robust)?robust:0,Double.isFinite(spread)?spread:1)*100;
            double hours = Math.max(1, (now - group.getLast().soldMillis()) / 3_600_000.0);
            result.put(entry.getKey(), new Stats(entry.getKey(), conservative, group.size(), units,
                    group.getFirst().soldMillis(), group.size() / hours,volatility));
        }
        return Map.copyOf(result);
    }
    private void persistHistory(List<Sale> values) {
        Path temp=null;
        try {
            Files.createDirectories(historyFile.getParent());
            temp=Files.createTempFile(historyFile.getParent(),"donut-sales-",".tmp");
            Files.writeString(temp,new Gson().toJson(new Saved(1,SOURCE,values)));
            Files.move(temp,historyFile,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
        }catch(IOException ignored){ /* Trading receipts remain in the independent budget ledger. */ }
        finally{if(temp!=null)try{Files.deleteIfExists(temp);}catch(IOException ignored){}}
    }
}

package dev.donuttrader;

import dev.donuttrader.mixin.DialogScreenAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.ContainerEventHandler;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.dialog.DialogScreen;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.dialog.Dialog;
import net.minecraft.server.dialog.body.ItemBody;
import net.minecraft.server.dialog.body.PlainMessage;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** 1.21.11 native dialog adapter; no positional clicks or guessed container slots. */
public final class NativeDialogs {
    private NativeDialogs() {}
    private static final Set<String> BUY = Set.of("buy", "confirm", "confirm purchase");
    private static final Set<String> SELL = Set.of("sell", "confirm", "confirm listing", "create auction");

    public static boolean isDialog(Screen screen) { return screen instanceof DialogScreen<?>; }
    public static boolean confirmPurchase(Minecraft client, ItemStack expected, long totalMinor) {
        return confirmPurchase(client, expected, totalMinor, totalMinor);
    }
    public static boolean confirmPurchase(Minecraft client, ItemStack expected, long minimumMinor, long maximumMinor) {
        return confirm(client, expected, minimumMinor, maximumMinor, BUY, "Alış");
    }
    public static boolean confirmSale(Minecraft client, ItemStack expected, long totalMinor) {
        return confirm(client, expected, totalMinor, totalMinor, SELL, "Satış");
    }

    private static boolean confirm(Minecraft client, ItemStack expected, long minimum, long maximum,
            Set<String> allowedLabels, String kind) {
        Screen screen = client.screen;
        if (!isDialog(screen)) return false;
        if (client.player == null || expected == null || expected.isEmpty())
            throw new IllegalStateException(kind + " onayında oyuncu/eşya bilgisi eksik");
        Dialog dialog = dialog(screen);
        List<Button> all = buttons(screen);
        if (all.isEmpty()) return false; // The native screen has not populated its controls yet.
        List<Button> matches = all.stream().filter(b -> allowedLabels.contains(NativeDialogProof.label(b.getMessage().getString()))).toList();
        if (matches.size() != 1)
            throw new IllegalStateException(kind + " onay düğmesi eksik veya belirsiz: " + describe(screen));
        long exactItems = dialog.common().body().stream().filter(body -> body instanceof ItemBody item && exactPlainItem(item.item(), expected)).count();
        long itemBodies = dialog.common().body().stream().filter(ItemBody.class::isInstance).count();
        boolean textOnlyProof = itemBodies == 0 && exactPlainItem(expected, expected)
                && NativeDialogProof.requireTextItem(text(dialog), new ItemStack(expected.getItem()).getHoverName().getString(), expected.getCount());
        if (!(itemBodies == 1 && exactItems == 1) && !textOnlyProof)
            throw new IllegalStateException(kind + " onayındaki eşya/adet imzası eşleşmedi: " + describe(screen));
        if (NativeDialogProof.totalWithin(text(dialog), minimum, maximum).isEmpty())
            throw new IllegalStateException(kind + " onayındaki toplam fiyat izin verilen aralıkta doğrulanamadı: " + describe(screen));
        if (client.screen != screen) return false;
        matches.getFirst().onPress(new MouseButtonInfo(0, 0));
        return true;
    }

    private static Dialog dialog(Screen screen) {
        if (!(screen instanceof DialogScreenAccessor accessor))
            throw new IllegalStateException("Native dialog erişim mixin'i etkin değil");
        return accessor.donuttrader$getDialog();
    }
    private static boolean exactPlainItem(ItemStack actual, ItemStack expected) {
        if (actual == null || actual.isEmpty() || actual.getCount() != expected.getCount()) return false;
        ItemStack a = actual.copy(), e = expected.copy();
        a.remove(DataComponents.LORE); e.remove(DataComponents.LORE); a.setCount(1); e.setCount(1);
        ItemStack vanilla = new ItemStack(e.getItem());
        return ItemStack.isSameItemSameComponents(a, e) && ItemStack.isSameItemSameComponents(e, vanilla);
    }
    private static String text(Dialog dialog) {
        StringBuilder result = new StringBuilder(dialog.common().title().getString());
        for (var body : dialog.common().body()) {
            if (body instanceof PlainMessage plain) result.append('\n').append(plain.contents().getString());
            if (body instanceof ItemBody item) {
                result.append('\n').append(item.item().getHoverName().getString());
                item.description().ifPresent(description -> result.append('\n').append(description.contents().getString()));
            }
        }
        return result.toString();
    }
    public static String describe(Screen screen) {
        if (!isDialog(screen)) return screen == null ? "ekran yok" : screen.getTitle().getString();
        try {
            Dialog dialog = dialog(screen);
            StringBuilder result = new StringBuilder(NativeDialogProof.stripFormatting(text(dialog)));
            for (var body : dialog.common().body()) if (body instanceof ItemBody item)
                result.append(" | ").append(BuiltInRegistries.ITEM.getKey(item.item().getItem())).append(" x").append(item.item().getCount());
            result.append(" | buttons=").append(buttons(screen).stream().map(b -> b.getMessage().getString()).toList());
            return result.substring(0, Math.min(result.length(), 700));
        } catch (RuntimeException missing) { return "native dialog: " + missing.getMessage(); }
    }
    private static List<Button> buttons(Screen screen) {
        List<Button> found = new ArrayList<>();
        Set<GuiEventListener> visited = Collections.newSetFromMap(new IdentityHashMap<>());
        collect(screen, found, visited, 0);
        return found;
    }
    private static void collect(ContainerEventHandler parent, List<Button> found, Set<GuiEventListener> visited, int depth) {
        if (depth >= 12) return;
        for (GuiEventListener child : parent.children()) {
            if (!visited.add(child)) continue;
            if (child instanceof Button button && button.active && button.visible) found.add(button);
            if (child instanceof ContainerEventHandler nested) collect(nested, found, visited, depth + 1);
        }
    }
}

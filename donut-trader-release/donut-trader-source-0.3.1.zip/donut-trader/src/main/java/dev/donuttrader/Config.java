package dev.donuttrader;

import java.util.*;
import java.util.regex.Pattern;

public final class Config {
    public long budget = 10_000_000;
    public double minNetMargin = 0.15;
    public double saleFee = 0.05; // Placeholder; arm requires explicit confirmation of the real fee.
    public double undercut = 0.01;
    public int minPeers = 5;
    public int intervalTicks = 100;
    public int timeoutTicks = 200;
    public int listingSlotLimit = 45;
    public String serverHost = "donutsmp.net";
    public String auctionCommand = "ah";
    public String sellCommand = "ah sell %d";
    public boolean profileVerified = false;
    public boolean feeVerified = false;
    public boolean priceIsStackTotalVerified = false;
    public boolean requireRecentSales = false;
    public boolean useWebReference = true;
    // Empty patterns deliberately match no screen. Configure from /dt inspect.
    public String auctionTitleRegex = "";
    public String confirmTitleRegex = "";
    public String priceLineRegex = "(?i)^Price:\\s*\\$?([0-9][0-9,.]*\\s*[kmb]?)$";
    public int confirmButtonSlot = -1;
    public String confirmButtonName = "";
    public int confirmItemSlot = -1;
    public Set<String> allowedItems = new HashSet<>();
    public Set<String> blockedItems = new HashSet<>();
    public boolean titleMatches(String regex, String title) {
        return !regex.isBlank() && Pattern.matches(regex, title);
    }
    public void validate() {
        if (allowedItems == null || blockedItems == null) throw new IllegalArgumentException("Invalid item filters");
        if (budget <= 0 || budget > 10_000_000 || intervalTicks < 40 || timeoutTicks < 40)
            throw new IllegalArgumentException("Budget must be 1..10000000; intervals >=40 ticks");
        if (listingSlotLimit < 1 || listingSlotLimit > 90) throw new IllegalArgumentException("Invalid listing slot limit");
        Market.best(List.of(), Set.of(), budget, minNetMargin, saleFee, undercut, minPeers);
        Pattern.compile(auctionTitleRegex); Pattern.compile(confirmTitleRegex);
        if (Pattern.compile(priceLineRegex).matcher("").groupCount() != 1)
            throw new IllegalArgumentException("priceLineRegex must have exactly one capture group");
        if (!auctionCommand.matches("[A-Za-z0-9 _-]+") || !sellCommand.matches("[A-Za-z0-9 _-]+%d"))
            throw new IllegalArgumentException("Invalid auction/sell command");
        if (serverHost.isBlank() || serverHost.contains("/") || serverHost.contains(":"))
            throw new IllegalArgumentException("serverHost must be a hostname without a port");
    }
    public boolean canArm() {
        return profileVerified && feeVerified && priceIsStackTotalVerified && !allowedItems.isEmpty()
            && !auctionTitleRegex.isBlank() && !confirmTitleRegex.isBlank()
            && confirmButtonSlot >= 0 && confirmItemSlot >= 0
            && confirmButtonSlot != confirmItemSlot && !confirmButtonName.isBlank();
    }
}

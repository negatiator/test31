package dev.donuttrader;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.regex.Pattern;

/** A displayed price range; compact labels never establish an exact debit. */
public record PriceQuote(long lowerMinor, long upperMinor) {
    public static final long MAX_MINOR = 100_000_000_000_000L;
    private static final Pattern LABEL = Pattern.compile(
        "(?i)^\\$?\\s*([0-9]+(?:,[0-9]{3})*(?:\\.([0-9]+))?)\\s*([kmb]?)$");

    public PriceQuote {
        if (lowerMinor < 1 || upperMinor < lowerMinor || upperMinor > MAX_MINOR)
            throw new IllegalArgumentException("Invalid price bounds");
    }

    public static PriceQuote parse(String label) {
        if (label == null || label.length() > 128) throw new IllegalArgumentException("Invalid price label");
        var match = LABEL.matcher(label.strip());
        if (!match.matches()) throw new IllegalArgumentException("Invalid price label");
        String amount = match.group(1);
        String suffix = match.group(3).toLowerCase(Locale.ROOT);
        try {
            long center = Market.moneyMinor(amount + suffix);
            if (center < 1 || center > MAX_MINOR) throw new IllegalArgumentException("Price is out of range");
            if (suffix.isEmpty()) return new PriceQuote(center, center);

            long multiplier = switch (suffix) {
                case "k" -> 1_000L;
                case "m" -> 1_000_000L;
                case "b" -> 1_000_000_000L;
                default -> throw new IllegalArgumentException("Unknown price suffix");
            };
            int decimals = match.group(2) == null ? 0 : match.group(2).length();
            long displayUnit = BigDecimal.valueOf(multiplier).scaleByPowerOfTen(-decimals)
                .movePointRight(2).longValueExact();
            if (displayUnit < 1) throw new IllegalArgumentException("Subminor price precision");
            long lower = Math.max(1, Math.subtractExact(center, displayUnit));
            long upper = Math.addExact(center, displayUnit);
            return new PriceQuote(lower, upper);
        } catch (ArithmeticException invalid) {
            throw new IllegalArgumentException("Price cannot be represented exactly in minor units", invalid);
        }
    }

    public boolean containsExact(long debitMinor) {
        return debitMinor >= lowerMinor && debitMinor <= upperMinor;
    }
}

package dev.donuttrader;

import java.util.*;

/** Pure valuation policy: observed asks and authenticated completed sales remain distinct evidence. */
public final class OpportunityModel {
    private OpportunityModel() {}
    public record Evaluation(List<Market.Deal> deals,String reason) {
        public Evaluation {deals=List.copyOf(deals);}
    }
    public static Evaluation evaluate(List<Market.Listing> rows,String target,long remaining,
            double margin,double fee,double undercut,int minPeers,Map<String,Long> webCaps,
            Map<String,OfficialMarket.Stats> history,long now) {
        OfficialMarket.Stats stats=history.get(target);
        if(stats!=null&&(stats.saleCount()<5||stats.unitMinor()<=0||stats.newestSaleMillis()>now
                ||now-stats.newestSaleMillis()>OfficialMarket.FRESH_MS||!Double.isFinite(stats.volatilityPct())
                ||stats.volatilityPct()<0))stats=null;
        if(stats!=null&&stats.volatilityPct()>30)
            return new Evaluation(List.of(),"Tamamlanan satislarda oynaklik %30'u asti; bu esya bekletiliyor");
        Map<String,Long> caps=new HashMap<>(webCaps);
        if(stats!=null)caps.merge(target,stats.unitMinor(),Math::min);
        boolean askOnly=caps.getOrDefault(target,0L)<=0;
        Map<Integer,Market.Deal> ranked=new HashMap<>();
        for(var d:Market.deals(rows,Set.of(target),remaining,margin,fee,undercut,minPeers,askOnly?null:caps))ranked.put(d.listing().slot(),d);
        if(stats!=null)for(var row:rows) {
            if(!row.itemId().equals(target)||row.price()>remaining||row.count()<=0)continue;
            long reference=caps.get(target);
            // Exact-component plain stacks can lower a historical unit estimate, never raise it.
            var peerUnits=rows.stream().filter(p->p.slot()!=row.slot()&&p.key().equals(row.key())&&p.count()>0)
                .mapToLong(p->p.referencePrice()/p.count()).filter(p->p>0).sorted().toArray();
            if(peerUnits.length>0)reference=Math.min(reference,peerUnits[(peerUnits.length-1)/4]);
            Market.fromReference(row,reference,margin,fee,undercut).ifPresent(d->
                ranked.merge(row.slot(),d,(a,b)->a.salePrice()<=b.salePrice()?a:b));
        }
        List<Market.Deal> deals=ranked.values().stream().sorted(Comparator.comparingLong(Market.Deal::netProfit).reversed()
                .thenComparingInt(d->d.listing().slot())).toList();
        if(!deals.isEmpty())return new Evaluation(deals,askOnly?
                "Canli ilan tahmininde firsat; gercek satis talebi bilinmiyor":"Firsat bulundu; envanter ve kendi ilanlarim kontrol ediliyor");
        var targetRows=rows.stream().filter(r->r.itemId().equals(target)).toList();
        if(targetRows.isEmpty())return new Evaluation(deals,"Bu sayfada eslesen standart ilan yok");
        if(targetRows.stream().noneMatch(r->r.price()<=remaining))return new Evaluation(deals,"Bu sayfadaki fiyatlar kalan alis butcesini asiyor");
        if(stats==null) {
            Map<String,Integer> counts=new HashMap<>();
            for(var r:targetRows)counts.merge(r.key()+"|count="+r.count(),1,Integer::sum);
            int peers=counts.values().stream().mapToInt(n->Math.max(0,n-1)).max().orElse(0);
            if(peers<minPeers)return new Evaluation(deals,"Karsilastirma az: "+peers+"/"+minPeers
                    +" ayni esya/adet akrani gerekli; satis verisi yok");
        }
        boolean unstable=targetRows.stream().anyMatch(r->Market.peerScatter(targetRows.stream()
                .filter(p->p.slot()!=r.slot()&&p.key().equals(r.key())&&p.count()==r.count())
                .map(Market.Listing::referencePrice).sorted().toList())>.30);
        if(unstable)return new Evaluation(deals,"Canli ilan fiyat dagilimi cok genis; oynak esya bekletiliyor");
        return new Evaluation(deals,"Fiyat farki, ucret tahmini sonrasi %"+Math.round(margin*100)+" net esigini karsilamiyor");
    }
}

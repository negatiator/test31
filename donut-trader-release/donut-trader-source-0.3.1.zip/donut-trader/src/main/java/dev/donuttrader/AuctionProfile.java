package dev.donuttrader;

import java.util.*;
import java.util.regex.Pattern;

/** Listing-page layout observed in the user's inspection; no purchase confirmation inferred. */
public final class AuctionProfile {
    private AuctionProfile() {}
    public static final String TITLE = "^Auction \\(Page [1-9][0-9]*\\)$";
    public static final String PRICE = "^\\$\\s*([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]+)?\\s*[kKmMbB]?)$";
    public static final Set<String> OBSERVED_MATERIALS = Set.of(
        "minecraft:granite", "minecraft:tuff", "minecraft:diorite", "minecraft:rail", "minecraft:andesite",
        "minecraft:polished_deepslate", "minecraft:polished_diorite", "minecraft:polished_granite",
        "minecraft:spruce_slab", "minecraft:calcite", "minecraft:gold_nugget", "minecraft:bowl",
        "minecraft:iron_nugget", "minecraft:packed_ice", "minecraft:oak_sapling", "minecraft:coarse_dirt");
    public static void apply(Config config) {
        config.auctionTitleRegex = TITLE;
        config.priceLineRegex = PRICE;
        config.listingSlotLimit = 45;
        if (config.allowedItems.isEmpty()) config.allowedItems.addAll(OBSERVED_MATERIALS);
        config.profileVerified = false; // Confirmation/fee/total-vs-unit semantics remain unverified.
    }
    public static OptionalLong priceMinor(List<String> lines, String regex) {
        var pattern = Pattern.compile(regex);
        Long result = null;
        for (String line : lines) {
            var matcher = pattern.matcher(line.replaceAll("§.", "").trim());
            if (!matcher.matches()) continue;
            if (result != null) return OptionalLong.empty();
            try { result = Market.moneyMinor(matcher.group(1)); }
            catch (RuntimeException invalid) { return OptionalLong.empty(); }
        }
        return result != null && result > 0 ? OptionalLong.of(result) : OptionalLong.empty();
    }
}

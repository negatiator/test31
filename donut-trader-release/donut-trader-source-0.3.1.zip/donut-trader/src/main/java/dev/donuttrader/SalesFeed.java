package dev.donuttrader;

import com.google.gson.Gson;
import java.nio.file.*;
import java.util.*;

/** Strictly bounded, recent completed-sales references produced by tools/market.py. */
public final class SalesFeed {
    public record Quote(String itemId, long unitSalePrice, int sampleCount, long newestSaleMillis, long oldestSaleMillis) {}
    private record Snapshot(int schemaVersion, String source, long fetchedAtMillis, List<Quote> quotes) {}
    private SalesFeed() {}
    public static Map<String, Quote> read(Path path, long now) {
        try {
            if (Files.size(path) > 1_000_000) return Map.of();
            Snapshot data = new Gson().fromJson(Files.readString(path), Snapshot.class);
            if (data == null || data.schemaVersion() != 1 || !"https://api.donutsmp.net".equals(data.source())
                    || data.fetchedAtMillis() <= 0 || now < data.fetchedAtMillis() || now - data.fetchedAtMillis() > 180_000 || data.quotes() == null) return Map.of();
            Map<String, Quote> result = new HashMap<>();
            for (Quote q : data.quotes()) {
                if (q.itemId() == null || !q.itemId().matches("minecraft:[a-z0-9_]+") || q.unitSalePrice() <= 0
                        || q.unitSalePrice() > 1_000_000_000_000L || q.sampleCount() < 5 || q.oldestSaleMillis() <= 0 || q.oldestSaleMillis() > q.newestSaleMillis()
                        || now < q.newestSaleMillis() || now - q.oldestSaleMillis() > 1_800_000) continue;
                if (result.putIfAbsent(q.itemId(), q) != null) return Map.of();
            }
            return Map.copyOf(result);
        } catch (Exception invalid) { return Map.of(); }
    }
}

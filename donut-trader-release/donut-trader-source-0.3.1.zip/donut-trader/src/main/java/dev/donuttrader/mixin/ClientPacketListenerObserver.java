package dev.donuttrader.mixin;

import dev.donuttrader.InventoryEvidence;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundContainerSetContentPacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.network.protocol.game.ClientboundSetPlayerInventoryPacket;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** RETURN runs only after Minecraft has applied an authoritative inventory packet. */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerObserver {
    @Inject(method = "handleContainerContent", at = @At("RETURN"))
    private void donuttrader$inventoryContent(ClientboundContainerSetContentPacket packet, CallbackInfo callback) {
        if (packet.containerId() == 0) InventoryEvidence.noteContent(packet.items().size());
        else {
            AbstractContainerMenu menu = donuttrader$activeMenu(packet.containerId());
            if (menu != null)
                for (int i = 0; i < Math.min(packet.items().size(), menu.slots.size()); i++)
                    donuttrader$noteMappedSlot(packet.containerId(), menu, i);
        }
    }
    @Inject(method = "handleContainerSetSlot", at = @At("RETURN"))
    private void donuttrader$inventorySlot(ClientboundContainerSetSlotPacket packet, CallbackInfo callback) {
        InventoryEvidence.noteContainerSlot(packet.getContainerId(), packet.getSlot());
        AbstractContainerMenu menu = donuttrader$activeMenu(packet.getContainerId());
        if (menu != null) donuttrader$noteMappedSlot(packet.getContainerId(), menu, packet.getSlot());
    }
    @Inject(method = "handleSetPlayerInventory", at = @At("RETURN"))
    private void donuttrader$playerInventory(ClientboundSetPlayerInventoryPacket packet, CallbackInfo callback) {
        InventoryEvidence.noteSlot(packet.slot());
    }

    @Unique
    private static AbstractContainerMenu donuttrader$activeMenu(int packetContainerId) {
        var player = Minecraft.getInstance().player;
        if (player == null || packetContainerId <= 0 || player.containerMenu.containerId != packetContainerId)
            return null;
        return player.containerMenu;
    }

    @Unique
    private static void donuttrader$noteMappedSlot(int packetContainerId, AbstractContainerMenu menu, int menuSlot) {
        var player = Minecraft.getInstance().player;
        if (player == null || menuSlot < 0 || menuSlot >= menu.slots.size()) return;
        Slot slot = menu.slots.get(menuSlot);
        InventoryEvidence.noteMappedSlot(packetContainerId, menu.containerId,
                slot.container == player.getInventory(), slot.getContainerSlot());
    }
}

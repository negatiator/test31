package dev.donuttrader;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Public asking-price snapshot, kept separate from evidence of completed sales. */
public final class WebMarket {
    public static final String SOURCE = "https://donutsmpterminal.com/snapshots/latest.json";
    public static final long MAX_AGE_MS = 6 * 60 * 60 * 1000L;
    private static final long REFRESH_MS = 5 * 60 * 1000L;
    private static final int MAX_BYTES = 2_000_000;
    public record Snapshot(long capturedAt, Map<String, Long> prices) {
        public Map<String, Long> freshPrices(long now) {
            return capturedAt > 0 && now >= capturedAt && now - capturedAt <= MAX_AGE_MS ? prices : Map.of();
        }
    }
    private volatile Snapshot snapshot = new Snapshot(0, Map.of());
    private volatile String error = "Henüz yüklenmedi";
    private long lastAttempt;
    private final AtomicBoolean inFlight = new AtomicBoolean();

    /** The site's own client maps [order, orderChange, AH, AHChange] in this order. */
    public static Snapshot parse(String json, long now) {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        if (root.get("v").getAsInt() != 1) throw new IllegalArgumentException("Unknown snapshot schema");
        long captured = Instant.parse(root.get("captured").getAsString()).toEpochMilli();
        if (captured <= 0 || captured > now || now - captured > MAX_AGE_MS)
            throw new IllegalArgumentException("Old or future snapshot");
        JsonObject items = root.getAsJsonObject("items");
        if (items == null || items.size() > 10_000) throw new IllegalArgumentException("Invalid items");
        Map<String, Long> prices = new HashMap<>();
        for (var entry : items.entrySet()) {
            if (!entry.getKey().matches("[a-z0-9_]+")) continue;
            if (!entry.getValue().isJsonArray()) continue;
            var row = entry.getValue().getAsJsonArray();
            if (row.size() != 4 || row.get(2).isJsonNull() || !row.get(2).isJsonPrimitive()
                    || !row.get(2).getAsJsonPrimitive().isNumber()) continue;
            // Use AH per-unit references, never buy-order prices or percentage columns.
            var value = row.get(2).getAsBigDecimal();
            if (value.compareTo(java.math.BigDecimal.ONE) < 0 || value.compareTo(java.math.BigDecimal.valueOf(1_000_000_000_000L)) > 0) continue;
            prices.put("minecraft:" + entry.getKey(), value.longValue());
        }
        if (prices.isEmpty()) throw new IllegalArgumentException("No AH prices");
        return new Snapshot(captured, Map.copyOf(prices));
    }

    public static Snapshot download() throws Exception {
        try (var client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8))
                .followRedirects(HttpClient.Redirect.NEVER).build()) {
            var request = HttpRequest.newBuilder(URI.create(SOURCE)).timeout(Duration.ofSeconds(15))
                .header("Accept", "application/json").header("User-Agent", "DonutTrader/0.1.2 (public price reference)").GET().build();
            var response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
            try (var body = response.body()) {
                if (response.statusCode() != 200) throw new IllegalStateException("HTTP " + response.statusCode());
                byte[] bytes = body.readNBytes(MAX_BYTES + 1);
                if (bytes.length > MAX_BYTES) throw new IllegalArgumentException("Snapshot too large");
                return parse(new String(bytes, java.nio.charset.StandardCharsets.UTF_8), System.currentTimeMillis());
            }
        }
    }

    /** Network I/O never runs on Minecraft's render/tick thread. */
    public void refresh(long now) {
        if (now - lastAttempt < REFRESH_MS || !inFlight.compareAndSet(false, true)) return;
        lastAttempt = now;
        Thread.ofPlatform().daemon().name("donut-trader-market").start(() -> {
            try { snapshot = download(); error = ""; }
            catch (Exception e) { error = e.getClass().getSimpleName(); }
            finally { inFlight.set(false); }
        });
    }
    public Map<String, Long> prices(long now) { return snapshot.freshPrices(now); }
    public String status(long now) {
        long minutes = snapshot.capturedAt() > 0 ? Math.max(0, now - snapshot.capturedAt()) / 60000 : -1;
        return "DonutSMP Terminal: " + prices(now).size() + " AH referansı; dosya yaşı=" + minutes
            + " dk; yükleniyor=" + inFlight.get() + (error.isBlank() ? "" : "; durum=" + error);
    }
}

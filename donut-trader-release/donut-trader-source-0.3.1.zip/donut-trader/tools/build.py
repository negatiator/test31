"""Use the environment's HTTPS proxy with Gradle without exposing authentication."""
import os
import shlex
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit

root = Path(__file__).resolve().parents[1]
env = os.environ.copy()
proxy = urlsplit(env.get("HTTPS_PROXY", env.get("https_proxy", "")))
options = shlex.split(env.get("JAVA_OPTS", ""))
if proxy.hostname:
    if proxy.username or proxy.password:
        raise SystemExit("Authenticated proxy: configure Gradle credentials securely; not copied to arguments.")
    for protocol in ("http", "https"):
        options.extend([f"-D{protocol}.proxyHost={proxy.hostname}", f"-D{protocol}.proxyPort={proxy.port or 80}"])
    # Keep TLS verification: the platform's system trust store includes its proxy CA.
    platform_trust = Path("/etc/ssl/certs/java/cacerts")
    if platform_trust.is_file():
        options.append(f"-Djavax.net.ssl.trustStore={platform_trust}")
env["JAVA_OPTS"] = shlex.join(options)
env.setdefault("GRADLE_USER_HOME", str(root.parent / ".gradle"))
local_jdk = root.parent / ".setup-tools" / "jdk21"
if (local_jdk / "bin" / "javac").exists():
    env["JAVA_HOME"] = str(local_jdk)
wrapper = "gradlew.bat" if os.name == "nt" else "./gradlew"
raise SystemExit(subprocess.call([wrapper, "--no-daemon", "--max-workers=2", "--console=plain", *(sys.argv[1:] or ["build"])], cwd=root, env=env))

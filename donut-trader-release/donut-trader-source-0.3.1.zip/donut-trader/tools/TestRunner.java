import javax.tools.ToolProvider;
import java.nio.file.*;
import java.net.URLClassLoader;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import javax.tools.Diagnostic;
import com.sun.source.util.JavacTask;

class TestRunner {
    public static void main(String[] args) throws Exception {
        var compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("Java 21 JDK required");
        var diagnostics = new DiagnosticCollector<JavaFileObject>();
        try (var manager = compiler.getStandardFileManager(diagnostics, null, null)) {
            var sources = manager.getJavaFileObjectsFromStrings(java.util.List.of(
                "src/main/java/dev/donuttrader/Market.java",
                "src/main/java/dev/donuttrader/Config.java",
                "src/main/java/dev/donuttrader/DonutTrader.java"));
            var task = (JavacTask) compiler.getTask(null, manager, diagnostics, java.util.List.of("-proc:none"), null, sources);
            task.parse();
            if (diagnostics.getDiagnostics().stream().anyMatch(d -> d.getKind() == Diagnostic.Kind.ERROR))
                throw new IllegalStateException("Source syntax errors: " + diagnostics.getDiagnostics());
            System.out.println("PASS: Java source syntax (not Fabric API type checking)");
        }
        Path out = Path.of("build/core-tests"); Files.createDirectories(out);
        int result = compiler.run(null, null, null, "-d", out.toString(),
                "src/main/java/dev/donuttrader/Market.java", "src/main/java/dev/donuttrader/Config.java", "tests/MarketTest.java");
        if (result != 0) throw new IllegalStateException("Compilation failed: " + result);
        try (var loader = new URLClassLoader(new java.net.URL[]{out.toUri().toURL()})) {
            loader.loadClass("MarketTest").getMethod("main", String[].class).invoke(null, (Object) new String[0]);
        }
    }
}

"""Read-only official DonutSMP sales feed. No gameplay or secret values are logged."""
import argparse
import json
import os
import sys
import tempfile
import time
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE = "https://api.donutsmp.net"
MAX_AGE_MS = 30 * 60 * 1000
PLAIN_ITEMS = {
    "diamond", "diamond_block", "emerald", "emerald_block", "iron_ingot", "iron_block",
    "gold_ingot", "gold_block", "netherite_ingot", "netherite_block", "ancient_debris",
    "golden_apple", "enchanted_golden_apple", "totem_of_undying", "sea_pickle",
    "obsidian", "end_crystal", "experience_bottle", "nether_star", "beacon",
}


def summarize(rows, now):
    """Use only recent, completed, plain-commodity sales; reject ambiguous variants."""
    groups = defaultdict(list)
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        item = row.get("item")
        if not isinstance(item, dict):
            continue
        if set(item) - {"id", "count", "display_name", "enchants", "lore", "contents"}:
            continue  # Unknown variant metadata requires an explicit schema update.
        raw_id = item.get("id", "")
        if not isinstance(raw_id, str):
            continue
        item_id = raw_id.removeprefix("minecraft:").lower()
        if item_id not in PLAIN_ITEMS:
            continue
        enchants = item.get("enchants") or {}
        if not isinstance(enchants, dict) or item.get("contents") or item.get("lore") or any(enchants.values()):
            continue
        display = str(item.get("display_name") or "").strip().lower()
        if display and display != item_id.replace("_", " "):
            continue
        count, stamp = item.get("count"), row.get("unixMillisDateSold")
        if type(count) is not int or count <= 0 or type(stamp) is not int or not 0 <= now - stamp <= MAX_AGE_MS:
            continue
        try:
            price = Decimal(str(row.get("price")))
            if not price.is_finite() or price <= 0:
                continue
            unit = price / count
            # Bound to integer-coin accounting; never create a fractional or huge reference.
            if unit < 1 or unit > 10**12:
                continue
        except (InvalidOperation, ValueError, TypeError):
            continue
        seller = row.get("seller") or {}
        if not isinstance(seller, dict):
            continue
        identity = (item_id, count, str(price), stamp, seller.get("uuid"))
        if identity in seen:
            continue
        seen.add(identity)
        groups["minecraft:" + item_id].append((unit, stamp))
    result = []
    for item_id, sales in sorted(groups.items()):
        if len(sales) < 5:
            continue
        prices = sorted(s[0] for s in sales)
        result.append({"itemId": item_id, "unitSalePrice": int(prices[(len(prices) - 1) // 4]),
                       "sampleCount": len(sales), "newestSaleMillis": max(s[1] for s in sales),
                       "oldestSaleMillis": min(s[1] for s in sales)})
    return {"schemaVersion": 1, "source": BASE, "fetchedAtMillis": now, "quotes": result}


def get_page(page, key):
    req = Request(f"{BASE}/v1/auction/transactions/{page}", headers={
        "User-Agent": "DonutTrader/0.1 (read-only sales analysis)",
        "Accept": "application/json", "Authorization": "Bearer " + key,
    })
    with urlopen(req, timeout=20) as response:
        payload = json.load(response)
    if payload.get("status") != 200 or not isinstance(payload.get("result"), list):
        raise ValueError("Unexpected API response; snapshot not updated")
    return payload["result"]


def save(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as f:
            temp = Path(f.name)
            json.dump(document, f, indent=2)
        os.replace(temp, path)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Minecraft config/donut-trader-market.json path")
    parser.add_argument("--pages", type=int, default=3, choices=range(1, 11))
    parser.add_argument("--loop", action="store_true", help="Refresh every 60 seconds until interrupted")
    args = parser.parse_args()
    key = os.environ.get("DONUT_API_KEY", "").strip()
    if not key:
        print("DONUT_API_KEY missing. Generate with /api in game; supply via secure environment settings. Do not send it in chat.", file=sys.stderr)
        return 2
    while True:
        try:
            rows = []
            for page in range(1, args.pages + 1):
                if page > 1:
                    time.sleep(0.5)
                rows.extend(get_page(page, key))
            snapshot = summarize(rows, int(time.time() * 1000))
            if not snapshot["quotes"]:
                print("No recent sales with enough comparable samples. Existing snapshot retained and will expire normally.", file=sys.stderr)
                return 3
            save(args.output, snapshot)
            print(f"Updated {len(snapshot['quotes'])} commodity references from {len(rows)} transaction rows.")
        except HTTPError as error:
            print(f"Official API HTTP {error.code}; no snapshot update. Check API access/key for 401/403; respect 429 rate limits.", file=sys.stderr)
            return 2
        except (URLError, ValueError, OSError) as error:
            # Avoid printing request objects, auth headers, or secret-bearing URLs.
            print(f"Market update failed ({type(error).__name__}); snapshot unchanged.", file=sys.stderr)
            return 2
        if not args.loop:
            return 0
        time.sleep(60)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)

import dev.donuttrader.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

class AutoPolicyTest {
    @Test void compactTenMillionCannotFitTenMillionBudget() {
        var quote=PriceQuote.parse("$10M");
        var row=AutoPolicy.listing(0,"plain","minecraft:diamond",1,quote);
        assertTrue(row.price()>Market.toMinor(10_000_000));
        SpendLedger ledger=new SpendLedger();ledger.upgrade();
        assertThrows(IllegalArgumentException.class,()->ledger.reserve(row.price(),Market.toMinor(10_000_000)));
    }
    @Test void budgetAndMarginUseUpperBoundWhilePeerEstimateUsesLower() {
        var quote=PriceQuote.parse("$2.5M");var row=AutoPolicy.listing(0,"plain","minecraft:diamond",1,quote);
        assertEquals(quote.upperMinor(),row.price());assertEquals(quote.lowerMinor(),row.referencePrice());
        SpendLedger ledger=new SpendLedger();ledger.upgrade();ledger.reserve(row.price(),Market.toMinor(10_000_000));
        assertEquals(Market.moneyMinor("2.6m"),ledger.committed);
    }
    @Test void optimisticInventoryStateCannotProveServerSwap() {
        assertFalse(AutoPolicy.serverSwapProven(10,10,true));
        assertFalse(AutoPolicy.serverSwapProven(10,9,true));
        assertFalse(AutoPolicy.serverSwapProven(10,11,false));
        assertTrue(AutoPolicy.serverSwapProven(10,11,true));
    }
    @Test void onlyANewUniquePersonalListingProvesRelisting() {
        assertFalse(AutoPolicy.ownListingProven(0,0));
        assertFalse(AutoPolicy.ownListingProven(0,2));
        assertFalse(AutoPolicy.ownListingProven(1,1));
        assertTrue(AutoPolicy.ownListingProven(0,1));
    }
    @Test void compactPeerCenterCannotCreateAnArtificialProfit() {
        List<Market.Listing> rows=new ArrayList<>();
        rows.add(AutoPolicy.listing(0,"plain","minecraft:diamond",1,PriceQuote.parse("$800")));
        for(int i=1;i<=5;i++)rows.add(AutoPolicy.listing(i,"plain","minecraft:diamond",1,PriceQuote.parse("$1K")));
        assertTrue(Market.best(rows,Set.of("minecraft:diamond"),Market.toMinor(10_000_000),.15,.10,.01,5).isEmpty());
    }
    @Test void exactCheapOfferStillQualifiesWithEstimatedFeeAndWebCap() {
        List<Market.Listing> rows=new ArrayList<>();
        rows.add(AutoPolicy.listing(0,"plain","minecraft:diamond",1,PriceQuote.parse("$500")));
        for(int i=1;i<=5;i++)rows.add(AutoPolicy.listing(i,"plain","minecraft:diamond",1,PriceQuote.parse("$1000")));
        var d=Market.best(rows,Set.of("minecraft:diamond"),Market.toMinor(10_000_000),.15,.10,.01,5,
            Map.of("minecraft:diamond",Market.toMinor(900))).orElseThrow();
        assertEquals("891",Market.formatMinor(d.salePrice()));
        assertEquals("301.9",Market.formatMinor(d.netProfit()));
    }
}

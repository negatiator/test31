import dev.donuttrader.InventoryEvidence;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryEvidenceTest {
    @Test void unrelatedContainerCannotConfirmPlayerHotbar() {
        long all = InventoryEvidence.epoch(), hotbar = InventoryEvidence.slotEpoch(0);
        InventoryEvidence.noteContainerSlot(17,36);
        assertEquals(all, InventoryEvidence.epoch());
        assertEquals(hotbar, InventoryEvidence.slotEpoch(0));
    }
    @Test void playerMenuHotbarSlotsMapToInventoryIndices() {
        long before = InventoryEvidence.slotEpoch(0);
        InventoryEvidence.noteContainerSlot(0,36);
        assertTrue(InventoryEvidence.slotEpoch(0) > before);
        long saved = InventoryEvidence.slotEpoch(0);
        InventoryEvidence.noteContainerSlot(0,10);
        assertEquals(saved,InventoryEvidence.slotEpoch(0));
    }
    @Test void directPlayerSlotUsesRawInventoryIndex() {
        long before = InventoryEvidence.slotEpoch(8);
        InventoryEvidence.noteContainerSlot(-2,8);
        assertTrue(InventoryEvidence.slotEpoch(8) > before);
    }
    @Test void fullPlayerContentAcknowledgesOnlyPresentInventorySlots() {
        long before = InventoryEvidence.slotEpoch(0);
        InventoryEvidence.noteContent(45);
        assertTrue(InventoryEvidence.slotEpoch(0) > before);
        assertEquals(InventoryEvidence.slotEpoch(0),InventoryEvidence.slotEpoch(35));
        assertEquals(-1,InventoryEvidence.slotEpoch(36));
    }
    @Test void activeAuctionPlayerSlotUsesResolvedInventoryIndex() {
        long before = InventoryEvidence.slotEpoch(8);
        InventoryEvidence.noteMappedSlot(17,17,true,8);
        assertTrue(InventoryEvidence.slotEpoch(8) > before);
    }
    @Test void staleMenuAndAuctionItemsCannotAcknowledgeInventory() {
        long before = InventoryEvidence.epoch();
        InventoryEvidence.noteMappedSlot(17,18,true,8);
        InventoryEvidence.noteMappedSlot(17,17,false,8);
        InventoryEvidence.noteMappedSlot(17,17,true,36);
        InventoryEvidence.noteMappedSlot(0,0,true,8);
        assertEquals(before,InventoryEvidence.epoch());
    }
}

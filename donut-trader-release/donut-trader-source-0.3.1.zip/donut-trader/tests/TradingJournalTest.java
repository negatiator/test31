import dev.donuttrader.TradingJournal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

public class TradingJournalTest {
    @TempDir Path temporary;
    @Test void listingEstimatesSurviveReloadWithoutInventingSales() {
        Path path=temporary.resolve("history.json");
        TradingJournal first=new TradingJournal(path);
        first.event("AUTO basladi");
        first.listed("minecraft:diamond",4,10000,15000,3500);
        TradingJournal loaded=new TradingJournal(path);
        assertEquals(1,loaded.listings());
        assertEquals(3500,loaded.estimatedProfitMinor());
        assertEquals(2,loaded.entries().size());
        assertTrue(loaded.entries().getLast().message().contains("Ilan dogrulandi"));
        assertEquals(0,loaded.entries().getFirst().cumulativeEstimatedProfitMinor());
    }
    @Test void corruptHistoryDoesNotTouchSeparateBudgetLedger() throws Exception {
        Path ledger=temporary.resolve("ledger.json"), history=temporary.resolve("history.json");
        Files.writeString(ledger,"{\"committed\":250000,\"currencyScale\":2}");
        Files.writeString(history,"{broken");
        TradingJournal loaded=new TradingJournal(history);
        assertEquals(0,loaded.listings());
        assertFalse(loaded.storageStatus().isBlank());
        assertTrue(Files.readString(ledger).contains("250000"));
    }
    @Test void ordinaryEventsNeverIncreaseEstimatedProfit() {
        TradingJournal journal=new TradingJournal(temporary.resolve("history.json"));
        journal.event("Firsat goruldu");journal.event("Alis ayrildi");journal.event("Durdu");
        assertEquals(0,journal.listings());assertEquals(0,journal.estimatedProfitMinor());
    }
}

import dev.donuttrader.*;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class OpportunityModelTest {
    static final long NOW=1_800_000_000_000L;
    static final String ID="minecraft:diamond";
    Market.Listing row(int slot,int count,long amount){return new Market.Listing(slot,"plain",ID,count,amount);}
    OfficialMarket.Stats stats(long unit,double volatility,long time){return new OfficialMarket.Stats(ID,unit,8,20,time,2,volatility);}
    OpportunityModel.Evaluation evaluate(List<Market.Listing> rows,Map<String,Long> web,Map<String,OfficialMarket.Stats> sales){
        return OpportunityModel.evaluate(rows,ID,1_000_000_000,.15,.10,.01,5,web,sales,NOW);
    }
    @Test void thinAskingPageDoesNotPretendToBeCompletedSales() {
        var e=evaluate(List.of(row(0,1,5000)),Map.of(ID,10000L),Map.of());
        assertTrue(e.deals().isEmpty());assertTrue(e.reason().contains("Karsilastirma az"));
    }
    @Test void freshCompletedSalesCanPriceThinLivePage() {
        var e=evaluate(List.of(row(0,1,5000)),Map.of(),Map.of(ID,stats(10000,5,NOW-1000)));
        assertEquals(9900,e.deals().getFirst().salePrice());
        assertEquals(3910,e.deals().getFirst().netProfit());
    }
    @Test void staleOrFutureHistoryCannotUnlockThinPage() {
        for(long time:List.of(NOW+1,NOW-OfficialMarket.FRESH_MS-1))
            assertTrue(evaluate(List.of(row(0,1,5000)),Map.of(ID,10000L),Map.of(ID,stats(10000,5,time))).deals().isEmpty());
    }
    @Test void volatileCompletedSalesBlockEvenApparentlyProfitableLivePeers() {
        List<Market.Listing> rows=new ArrayList<>();rows.add(row(0,1,5000));
        for(int i=1;i<=5;i++)rows.add(row(i,1,10000));
        var e=evaluate(rows,Map.of(ID,10000L),Map.of(ID,stats(10000,31,NOW-1000)));
        assertTrue(e.deals().isEmpty());assertTrue(e.reason().contains("oynaklik"));
    }
    @Test void publicReferenceCanOnlyLowerHistoricalEstimate() {
        var e=evaluate(List.of(row(0,1,5000)),Map.of(ID,9000L),Map.of(ID,stats(10000,5,NOW-1000)));
        assertEquals(8910,e.deals().getFirst().salePrice());
    }
    @Test void differentlySizedPlainPeerCanLowerCompletedSaleUnitEstimate() {
        var e=evaluate(List.of(row(0,2,9000),row(1,1,6000)),Map.of(),Map.of(ID,stats(10000,5,NOW-1000)));
        var two=e.deals().stream().filter(d->d.listing().count()==2).findFirst().orElseThrow();
        assertEquals(11880,two.salePrice());
    }
    @Test void peerCountReasonRespectsStackSize() {
        List<Market.Listing> rows=new ArrayList<>();for(int i=0;i<6;i++)rows.add(row(i,i+1,5000));
        var e=evaluate(rows,Map.of(ID,10000L),Map.of());
        assertTrue(e.deals().isEmpty());assertTrue(e.reason().contains("0/5"));
    }
    @Test void invalidVolatilityDoesNotFabricateReference() {
        assertTrue(evaluate(List.of(row(0,1,5000)),Map.of(),Map.of(ID,stats(10000,Double.NaN,NOW-1000))).deals().isEmpty());
    }
    @Test void missingExternalFeedStillAllowsExplicitlyLabelledLivePeerEstimate() {
        List<Market.Listing> rows=new ArrayList<>();rows.add(row(0,1,5000));
        for(int i=1;i<=5;i++)rows.add(row(i,1,10000));
        var e=evaluate(rows,Map.of(),Map.of());
        assertFalse(e.deals().isEmpty());assertTrue(e.reason().contains("gercek satis talebi bilinmiyor"));
    }
    @Test void broadLivePeerBookCannotCreateAnArtificialStableFlip() {
        List<Market.Listing> rows=new ArrayList<>();rows.add(row(0,1,1000));
        long[] peers={5000,10000,20000,30000,40000};
        for(int i=0;i<peers.length;i++)rows.add(row(i+1,1,peers[i]));
        var e=evaluate(rows,Map.of(),Map.of());
        assertTrue(e.deals().isEmpty());assertTrue(e.reason().contains("oynak"));
    }
}

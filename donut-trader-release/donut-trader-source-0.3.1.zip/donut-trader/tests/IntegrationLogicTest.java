import dev.donuttrader.SalesFeed;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class IntegrationLogicTest {
    @TempDir Path temp;
    private static final long NOW = 1_800_000_000_000L;
    private Path snapshot(long fetched, long oldest, int count) throws Exception {
        Path file = temp.resolve("feed.json");
        Files.writeString(file, """
            {"schemaVersion":1,"source":"https://api.donutsmp.net","fetchedAtMillis":%d,
            "quotes":[{"itemId":"minecraft:diamond","unitSalePrice":20000,"sampleCount":%d,
            "newestSaleMillis":%d,"oldestSaleMillis":%d}]}
            """.formatted(fetched, count, NOW - 1000, oldest));
        return file;
    }
    @Test void marketChecks() { MarketTest.main(new String[0]); }
    @Test void freshSalesAccepted() throws Exception {
        assertEquals(20000, SalesFeed.read(snapshot(NOW, NOW - 10000, 5), NOW).get("minecraft:diamond").unitSalePrice());
    }
    @Test void oldSnapshotRejected() throws Exception {
        assertTrue(SalesFeed.read(snapshot(NOW - 180001, NOW - 10000, 5), NOW).isEmpty());
    }
    @Test void oldActualSalesRejectedEvenIfFetchedNow() throws Exception {
        assertTrue(SalesFeed.read(snapshot(NOW, NOW - 1800001, 5), NOW).isEmpty());
    }
    @Test void futureSnapshotRejected() throws Exception {
        assertTrue(SalesFeed.read(snapshot(NOW + 1, NOW - 10000, 5), NOW).isEmpty());
    }
    @Test void insufficientSalesRejected() throws Exception {
        assertTrue(SalesFeed.read(snapshot(NOW, NOW - 10000, 4), NOW).isEmpty());
    }
    @Test void invalidAndMissingSnapshotRejected() throws Exception {
        assertTrue(SalesFeed.read(temp.resolve("missing.json"), NOW).isEmpty());
        Path bad = temp.resolve("bad.json"); Files.writeString(bad, "{}");
        assertTrue(SalesFeed.read(bad, NOW).isEmpty());
    }
    @Test void wrongSourceRejected() throws Exception {
        Path p = snapshot(NOW, NOW - 10000, 5);
        Files.writeString(p, Files.readString(p).replace("api.donutsmp.net", "example.com"));
        assertTrue(SalesFeed.read(p, NOW).isEmpty());
    }
}

import dev.donuttrader.NativeDialogProof;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class NativeDialogProofTest {
    @Test void fullDecimalTotalsMatchExactly() {
        assertTrue(NativeDialogProof.totalWithin("Buy 64 Granite for $24.9?",2490,2490).isPresent());
        assertTrue(NativeDialogProof.totalWithin("Price: §a$ 1,250.25",125025,125025).isPresent());
        assertTrue(NativeDialogProof.totalWithin("Buy 64 Granite for $24.9?",2480,2500).isPresent());
    }
    @Test void wrongAmountsCannotPassOnItemQuantityOrSubstring() {
        assertTrue(NativeDialogProof.totalWithin("Buy 64 Granite for $24.9?",64,64).isEmpty());
        assertTrue(NativeDialogProof.totalWithin("Buy for $124.90",2490,2490).isEmpty());
        assertTrue(NativeDialogProof.totalWithin("Buy for $24.91",2490,2490).isEmpty());
    }
    @Test void compactDisplayMustFitEntireReservedInterval() {
        assertTrue(NativeDialogProof.totalWithin("Buy for $1.2M",120_000_000,129_999_999).isPresent());
        assertTrue(NativeDialogProof.totalWithin("Buy for $1.2M",120_000_000,120_000_000).isEmpty());
        assertTrue(NativeDialogProof.totalWithin("Buy for $1.2M",119_999_999,129_999_998).isEmpty());
    }
    @Test void ambiguousTotalsAndFeesRequireExplicitProof() {
        assertTrue(NativeDialogProof.totalWithin("Price $24.9. Balance $100",2490,2490).isEmpty());
        assertTrue(NativeDialogProof.totalWithin("Price $24.9; fee $1",2490,2490).isEmpty());
        assertTrue(NativeDialogProof.totalWithin("Price $24.9; confirm $24.9",2490,2490).isPresent());
    }
    @Test void malformedOrMissingAmountsStayBlocked() {
        for (String value : new String[]{"Buy for 24.9", "$-1", "$0", "$1,2", "$24.999", "$99999999999999999999999999B"})
            assertTrue(NativeDialogProof.totalWithin(value,2490,2490).isEmpty(),value);
    }
    @Test void explicitActionLabelsNormalizeFormattingOnly() {
        assertEquals("confirm purchase",NativeDialogProof.label("§aConfirm Purchase!"));
        assertEquals("confirm listing",NativeDialogProof.label("§aCONFIRM LISTING"));
        assertEquals("buy",NativeDialogProof.label("§2Buy"));
        assertEquals("confirm purchase",NativeDialogProof.label("𝐂𝐨𝐧𝐟𝐢𝐫𝐦 𝐏𝐮𝐫𝐜𝐡𝐚𝐬𝐞"));
        assertNotEquals("confirm",NativeDialogProof.label("Do Not Confirm"));
    }
    @Test void textOnlyProofRequiresExplicitAdjacentQuantityAndFullItemName() {
        for (String text : new String[]{"64x Diamond", "64 x Diamond", "Diamond x64", "64 Diamond",
                "Do you want to buy 64x Diamond for $12.50?", "Confirm Purchase\nDiamond x64\nTotal: $12.50",
                "Purchase of 64 Diamond at $12.50"})
            assertTrue(NativeDialogProof.requireTextItem(text,"Diamond",64),text);
    }
    @Test void textOnlyProofNeverConfusesItemPrefixesOrCounts() {
        for (String text : new String[]{"64x Diamond Block", "Diamond Block x64", "Buy Diamond Block x64 for $12.50",
                "Buy Packed Ice x64 for $12.50", "Buy 640 Diamond for $12.50", "Buy Diamond x640 for $12.50",
                "Buy Diamond for $64", "64 Diamonds", "64x Diamond Sword", "Buy Named Diamond x64 for $12.50"})
            assertFalse(NativeDialogProof.requireTextItem(text,"Diamond",64),text);
        assertFalse(NativeDialogProof.requireTextItem("Buy Packed Ice x64 for $12.50","Ice",64));
        assertTrue(NativeDialogProof.requireTextItem("Buy Packed Ice x64 for $12.50","Packed Ice",64));
    }
    @Test void singleItemStillRequiresExplicitOne() {
        assertFalse(NativeDialogProof.requireTextItem("Buy Diamond for $10","Diamond",1));
        assertTrue(NativeDialogProof.requireTextItem("Buy 1x Diamond for $10","Diamond",1));
    }
}

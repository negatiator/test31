import dev.donuttrader.WebMarket;
import dev.donuttrader.Market;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Instant;
import java.util.Map;

class WebMarketTest {
    private static final long NOW = Instant.parse("2026-10-21T09:00:00Z").toEpochMilli();
    private String json(String captured, String items) {
        return "{\"v\":1,\"captured\":\"" + captured + "\",\"items\":" + items + "}";
    }
    @Test void selectsAHColumnInsteadOfOrderOrChange() {
        var data = WebMarket.parse(json("2026-10-21T05:45:00Z", "{\"diamond\":[6800,0,8000,-46.7]}"), NOW);
        assertEquals(8000, data.freshPrices(NOW).get("minecraft:diamond"));
    }
    @Test void floorsFractionalPricesConservatively() {
        var data = WebMarket.parse(json("2026-10-21T05:45:00Z", "{\"emerald_block\":[5800,-27.5,29082.63,0]}"), NOW);
        assertEquals(29082, data.prices().get("minecraft:emerald_block"));
    }
    @Test void staleCaptureRejectedEvenWhenDownloadedNow() {
        assertThrows(IllegalArgumentException.class, () -> WebMarket.parse(json("2026-10-21T02:59:59Z", "{\"diamond\":[1,0,8,0]}"), NOW));
    }
    @Test void futureCaptureRejected() {
        assertThrows(IllegalArgumentException.class, () -> WebMarket.parse(json("2026-10-21T09:00:01Z", "{\"diamond\":[1,0,8,0]}"), NOW));
    }
    @Test void cachedCaptureExpiresWithoutRefetch() {
        var data = WebMarket.parse(json("2026-10-21T05:45:00Z", "{\"diamond\":[1,0,8,0]}"), NOW);
        assertTrue(data.freshPrices(Instant.parse("2026-10-21T11:45:01Z").toEpochMilli()).isEmpty());
    }
    @Test void missingAHDoesNotFallBackToBuyOrder() {
        assertThrows(IllegalArgumentException.class, () -> WebMarket.parse(json("2026-10-21T05:45:00Z", "{\"diamond\":[8000,0,null,0]}"), NOW));
    }
    @Test void malformedAndExtremeEntriesCannotBeUsed() {
        var data = WebMarket.parse(json("2026-10-21T05:45:00Z", "{\"diamond\":[1,0,8,0],\"gold_ingot\":[1,0,-3,0],\"bad/id\":[1,0,5,0],\"emerald\":[1,0,1000000000001,0],\"iron_ingot\":[1,0,\"900\",0]}"), NOW);
        assertEquals(Map.of("minecraft:diamond", 8L), data.prices());
    }
    @Test void unknownSchemaRejected() {
        assertThrows(IllegalArgumentException.class, () -> WebMarket.parse(json("2026-10-21T05:45:00Z", "{}").replace("\"v\":1", "\"v\":2"), NOW));
    }
    @Test void referenceCanRejectAnOtherwiseProfitableLiveListing() {
        var l = new Market.Listing(0, "plain", "minecraft:diamond", 64, 1_000_000);
        var d = new Market.Deal(l, 1_386_000, 316_700);
        assertTrue(Market.capBySales(d, 8000, .15, .05, .01).isEmpty());
    }
}

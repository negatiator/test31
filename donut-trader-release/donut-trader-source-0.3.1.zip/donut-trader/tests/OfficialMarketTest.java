import dev.donuttrader.OfficialMarket;
import dev.donuttrader.OfficialMarket.Sale;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class OfficialMarketTest {
    @TempDir Path directory;
    static final long NOW=1_800_000_000_000L;
    String row(String item,String price,String count,String metadata,long time) {
        return "{\"item\":{\"id\":\"minecraft:"+item+"\",\"count\":"+count+metadata+"},\"price\":"+price
                +",\"seller\":{\"name\":\"SellerOne\"},\"unixMillisDateSold\":\""+time+"\"}";
    }
    String response(String... rows){return "{\"status\":200,\"result\":["+String.join(",",rows)+"]}";}
    List<Sale> stable(int n,long age){
        List<Sale> sales=new ArrayList<>();
        for(int i=0;i<n;i++)sales.add(new Sale("minecraft:diamond",2,20000,"seller"+(i%3),NOW-age-i*1000));
        return sales;
    }
    @Test void absentCredentialHasNoMockOrCompletedSalePrices() {
        OfficialMarket market=new OfficialMarket(directory);
        assertFalse(market.hasKey());assertTrue(market.stats(NOW).isEmpty());
        market.refresh(NOW);assertTrue(market.status(NOW).contains("verisi yok"));
    }
    @Test void numericStringsAndExactDecimalPricesAreAccepted() {
        var data=OfficialMarket.parseSales(response(row("diamond","\"24.90\"","\"2\"",",\"display_name\":\"Diamond\"",NOW)),NOW);
        assertEquals(1,data.size());assertEquals(2490,data.getFirst().totalMinor());assertEquals(2,data.getFirst().count());
    }
    @Test void customizedOrUnknownMetadataCannotBecomePlainCommodityEvidence() {
        var data=OfficialMarket.parseSales(response(
                row("diamond","100","1",",\"lore\":[\"special\"]",NOW),
                row("diamond","100","1",",\"display_name\":\"Rare Diamond\"",NOW),
                row("diamond","100","1",",\"custom_model_data\":2",NOW),
                row("diamond_sword","100","1","",NOW)),NOW);
        assertTrue(data.isEmpty());
    }
    @Test void overlappingPagesDeduplicateInsteadOfInflatingSaleCount() {
        String same=row("diamond","100","1","",NOW);
        assertEquals(1,OfficialMarket.parseSales(response(same,same),NOW).size());
        List<Sale> repeated=new ArrayList<>();for(int i=0;i<8;i++)repeated.add(stable(1,1000).getFirst());
        assertTrue(OfficialMarket.summarize(repeated,NOW).isEmpty());
    }
    @Test void futureStaleAndSubcentRowsAreRejected() {
        assertTrue(OfficialMarket.parseSales(response(
                row("diamond","100","1","",NOW+1),
                row("diamond","100","1","",NOW-OfficialMarket.HISTORY_MS-1),
                row("diamond","1.001","1","",NOW)),NOW).isEmpty());
        assertTrue(OfficialMarket.summarize(stable(6,OfficialMarket.FRESH_MS+1),NOW).isEmpty());
    }
    @Test void fiveAcceptedSalesAndThreeSellersAreRequired() {
        assertTrue(OfficialMarket.summarize(stable(4,1000),NOW).isEmpty());
        List<Sale> concentrated=new ArrayList<>();
        for(int i=0;i<10;i++)concentrated.add(new Sale("minecraft:diamond",1,10000,"one-seller",NOW-i*1000));
        assertTrue(OfficialMarket.summarize(concentrated,NOW).isEmpty());
        var s=OfficialMarket.summarize(stable(6,1000),NOW).get("minecraft:diamond");
        assertNotNull(s);assertEquals(10000,s.unitMinor());assertEquals(6,s.saleCount());assertEquals(12,s.units());
    }
    @Test void gonutsOutlierFilterCannotLetOneHugeSaleSetFairValue() {
        List<Sale> sales=stable(6,1000);
        sales.add(new Sale("minecraft:diamond",1,99_999_999,"troll",NOW));
        var s=OfficialMarket.summarize(sales,NOW).get("minecraft:diamond");
        assertEquals(10000,s.unitMinor());assertEquals(6,s.saleCount());assertEquals(0,s.volatilityPct());
    }
    @Test void unitEstimateRoundsDownAndDoesNotInventSubcentProfit() {
        List<Sale> sales=new ArrayList<>();
        for(int i=0;i<6;i++)sales.add(new Sale("minecraft:diamond",2,249,"seller"+(i%3),NOW-i*1000));
        assertEquals(124,OfficialMarket.summarize(sales,NOW).get("minecraft:diamond").unitMinor());
    }
    @Test void credentialStaysLocalAndOutOfStatuses() throws Exception {
        OfficialMarket market=new OfficialMarket(directory);String key="test-secret-not-real";
        market.setKey(key);assertTrue(market.hasKey());
        assertFalse(market.status(NOW).contains(key));
        assertEquals(key,Files.readString(directory.resolve("donut-trader-api-key.txt")));
        assertTrue(market.stats(NOW).isEmpty());
        assertThrows(IllegalArgumentException.class,()->market.setKey("abc\nsecret"));
    }
    @Test void hostileNumericAndDeepInputsAreBounded() {
        assertTrue(OfficialMarket.parseSales(response(row("diamond","1e1000","1","",NOW)),NOW).isEmpty());
        assertThrows(IllegalArgumentException.class,()->OfficialMarket.parseSales("[".repeat(30)+"]".repeat(30),NOW));
        assertTrue(OfficialMarket.retryDelay("999999999999999999999999",NOW)>=30_000);
        assertTrue(OfficialMarket.retryDelay("99999999",NOW)<=30*60_000L);
    }
}

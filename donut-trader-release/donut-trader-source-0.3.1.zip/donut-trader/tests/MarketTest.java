import dev.donuttrader.Market;
import dev.donuttrader.Config;
import java.util.*;

public class MarketTest {
    static int checks;
    static void check(boolean value, String name) {
        checks++;
        if (!value) throw new AssertionError(name);
    }
    static void rejects(String text) {
        boolean rejected = false;
        try { Market.money(text); } catch (RuntimeException e) { rejected = true; }
        check(rejected, "Reject " + text);
    }
    public static void main(String[] args) {
        check(Market.money("10m") == 10_000_000, "10m budget");
        check(Market.money("$1,250,000") == 1_250_000, "comma separators");
        check(Market.money("1.25K") == 1250, "decimal suffix");
        for (String s : List.of("-1", "0.1", "1,2", "10m each", "NaN", "999999999999999999999b")) rejects(s);
        var cheap = new Market.Listing(0, "diamond|plain", "minecraft:diamond", 64, 1_000_000);
        var rows = new ArrayList<Market.Listing>(); rows.add(cheap);
        for (int i = 1; i <= 5; i++) rows.add(new Market.Listing(i, cheap.key(), cheap.itemId(), 64, 1_400_000));
        var allowed = Set.of("minecraft:diamond");
        var deal = Market.best(rows, allowed, 10_000_000, .15, .05, .01, 5).orElseThrow();
        check(deal.listing().slot() == 0, "Select bargain");
        check(deal.salePrice() == 1_386_000, "Undercut price");
        check(deal.netProfit() == 316_700, "Net after fee");
        check(Market.best(rows, allowed, 999_999, .15, .05, .01, 5).isEmpty(), "Budget cap");
        check(Market.best(rows, Set.of(), 10_000_000, .15, .05, .01, 5).isEmpty(), "Allowlist mandatory");
        check(Market.best(rows, allowed, 10_000_000, .50, .05, .01, 5).isEmpty(), "Margin threshold");
        check(Market.best(rows, allowed, 10_000_000, .15, .30, .01, 5).isEmpty(), "Fee removes opportunity");
        check(Market.best(rows.subList(0, 5), allowed, 10_000_000, .15, .05, .01, 5).isEmpty(), "Insufficient peers");
        var mixed = new ArrayList<Market.Listing>(); mixed.add(cheap);
        for (int i = 1; i <= 5; i++) mixed.add(new Market.Listing(i, "diamond|enchanted", cheap.itemId(), 64, 9_000_000));
        check(Market.best(mixed, allowed, 10_000_000, .15, .05, .01, 5).isEmpty(), "Components cannot mix");
        mixed.clear(); mixed.add(cheap);
        for (int i = 1; i <= 5; i++) mixed.add(new Market.Listing(i, cheap.key(), cheap.itemId(), 1, 9_000_000));
        check(Market.best(mixed, allowed, 10_000_000, .15, .05, .01, 5).isEmpty(), "Stack counts cannot mix");
        rows.set(5, new Market.Listing(5, cheap.key(), cheap.itemId(), 64, 99_000_000));
        check(Market.best(rows, allowed, 10_000_000, .15, .05, .01, 5).orElseThrow().salePrice() == 1_386_000, "Outlier cannot inflate reference");
        check(Market.best(rows, allowed, 0, .15, .05, .01, 5).isEmpty(), "No remaining budget");
        var config = new Config(); config.validate();
        check(!config.requireRecentSales, "Default mode does not require API access");
        var matcher = java.util.regex.Pattern.compile(config.priceLineRegex).matcher("Price: $1.25M");
        check(matcher.matches() && Market.money(matcher.group(1)) == 1_250_000, "Default price lore parses real whitespace and currency");
        check(config.budget == 10_000_000 && config.minNetMargin == .15, "Requested defaults");
        check(!config.canArm(), "Unverified profile cannot trade");
        check(!config.titleMatches("", "Auction House"), "Empty title is disabled");
        config.budget = 10_000_001;
        boolean invalidBudget = false;
        try { config.validate(); } catch (IllegalArgumentException e) { invalidBudget = true; }
        check(invalidBudget, "Ten million hard ceiling");
        config = new Config(); config.saleFee = Double.NaN;
        boolean invalidFee = false;
        try { config.validate(); } catch (IllegalArgumentException e) { invalidFee = true; }
        check(invalidFee, "NaN fee rejected");
        var uncapped = new Market.Deal(cheap, 1_386_000, 316_700);
        check(Market.capBySales(uncapped, 10000, .15, .05, .01).isEmpty(), "Real sales can reject expensive asks");
        check(Market.capBySales(uncapped, 25000, .15, .05, .01).orElseThrow().salePrice() == 1_386_000, "Sales cap never raises price");
        check(Market.best(rows, allowed, 10_000_000, .15, .05, .01, 5, Map.of()).isEmpty(), "Missing sales reject purchase");
        System.out.println("PASS: " + checks + " market checks");
    }
}

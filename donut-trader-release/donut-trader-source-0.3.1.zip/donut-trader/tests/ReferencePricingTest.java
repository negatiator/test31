import dev.donuttrader.Market;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ReferencePricingTest {
    private Market.Listing listing(int count,long cost){return new Market.Listing(3,"diamond","minecraft:diamond",count,cost);}
    @Test void completedSaleUnitReferenceScalesToCandidateQuantityAndFees() {
        var deal=Market.fromReference(listing(4,20000),10000,.15,.10,.01).orElseThrow();
        assertEquals(39600,deal.salePrice());
        assertEquals(15640,deal.netProfit());
    }
    @Test void referenceCannotInventPositiveProfitFromNegativeOrUnknownEvidence() {
        assertTrue(Market.fromReference(listing(4,40000),10000,.15,.10,.01).isEmpty());
        assertTrue(Market.fromReference(listing(4,20000),0,.15,.10,.01).isEmpty());
        assertTrue(Market.fromReference(listing(0,20000),10000,.15,.10,.01).isEmpty());
    }
    @Test void fractionalCoinTargetIsNotTruncatedToWholeCoins() {
        var deal=Market.fromReference(listing(1,1200),2490,.15,.10,.01).orElseThrow();
        assertEquals(2465,deal.salePrice());
        assertEquals("24.65",Market.formatMinor(deal.salePrice()));
    }
}

import dev.donuttrader.WebMarket;

/** Explicit live verification; not part of the deterministic test suite. */
public class WebMarketProbe {
    public static void main(String[] args) throws Exception {
        var snapshot = WebMarket.download();
        var prices = snapshot.freshPrices(System.currentTimeMillis());
        if (prices.isEmpty()) throw new AssertionError("No current public price references");
        System.out.println("Source: " + WebMarket.SOURCE);
        System.out.println("Captured: " + java.time.Instant.ofEpochMilli(snapshot.capturedAt()));
        System.out.println("Valid AH references: " + prices.size());
        for (String id : java.util.List.of("minecraft:diamond", "minecraft:ancient_debris", "minecraft:netherite_ingot")) {
            if (!prices.containsKey(id)) throw new AssertionError("Missing expected item: " + id);
            System.out.println(id + " AH/unit=" + prices.get(id));
        }
    }
}

import dev.donuttrader.Market;
import dev.donuttrader.PriceQuote;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class PriceQuoteTest {
    @Test void ordinaryCurrencyIsExactIncludingFractionalCoins() {
        for (String input : List.of("24.9", "$24.9", "$ 24.9", "  $ 24.90  ")) {
            var quote = PriceQuote.parse(input);
            assertEquals(2490, quote.lowerMinor());
            assertEquals(2490, quote.upperMinor());
            assertTrue(quote.containsExact(2490));
            assertFalse(quote.containsExact(2489));
            assertFalse(quote.containsExact(2491));
        }
        assertEquals(new PriceQuote(123450, 123450), PriceQuote.parse("$ 1,234.50"));
    }

    @Test void compactMillionsIncludeAnEntireLastDigitInBothDirections() {
        var quote = PriceQuote.parse("$2.5M");
        assertEquals(Market.toMinor(2_400_000), quote.lowerMinor());
        assertEquals(Market.toMinor(2_600_000), quote.upperMinor());
        assertTrue(quote.containsExact(Market.toMinor(2_450_000)));
        assertTrue(quote.containsExact(Market.toMinor(2_599_999)));
        assertFalse(quote.containsExact(quote.upperMinor() + 1));
    }

    @Test void tenMillionDisplayCannotBeAuthorizedByATenMillionBudget() {
        var quote = PriceQuote.parse("10M");
        assertEquals(Market.toMinor(9_000_000), quote.lowerMinor());
        assertEquals(Market.toMinor(11_000_000), quote.upperMinor());
        assertTrue(quote.upperMinor() > Market.toMinor(10_000_000));
    }

    @Test void displayedPrecisionControlsKiloAndMillionBudgetBounds() {
        assertEquals(new PriceQuote(Market.toMinor(2400), Market.toMinor(2600)), PriceQuote.parse("2.5K"));
        assertEquals(new PriceQuote(Market.toMinor(990), Market.toMinor(1010)), PriceQuote.parse("1.00k"));
        var fine = PriceQuote.parse("9.99M");
        assertEquals(Market.toMinor(9_980_000), fine.lowerMinor());
        assertEquals(Market.toMinor(10_000_000), fine.upperMinor());
    }

    @Test void lowerBoundNeverBecomesZeroAndOneMinorPrecisionIsSupported() {
        assertEquals(new PriceQuote(1, 2), PriceQuote.parse("0.00001K"));
        assertEquals(new PriceQuote(1, 1), PriceQuote.parse("0.01"));
        assertEquals(1, PriceQuote.parse("1K").lowerMinor());
    }

    @Test void malformedSubminorAndOverflowingPricesAreRejected() {
        for (String input : List.of("", "-1", "0", "$0.00", "1,2", "1.2.3", "NaN", "Infinity", "Price: 10", "10T",
                "1e3", "1K each", "24.999", "0.000001K", "1.000000K", "1000B", "999999999999999999999999999999M"))
            assertThrows(IllegalArgumentException.class, () -> PriceQuote.parse(input), input);
        assertThrows(IllegalArgumentException.class, () -> PriceQuote.parse(null));
        assertThrows(IllegalArgumentException.class, () -> new PriceQuote(0, 1));
        assertThrows(IllegalArgumentException.class, () -> new PriceQuote(2, 1));
    }

    @Test void supportedCeilingAppliesToTheUpperBoundNotOnlyTheDisplayedCenter() {
        assertEquals(PriceQuote.MAX_MINOR, PriceQuote.parse("1000000000000").upperMinor());
        assertEquals(PriceQuote.MAX_MINOR, PriceQuote.parse("999B").upperMinor());
        assertThrows(IllegalArgumentException.class, () -> PriceQuote.parse("1000B"));
        assertThrows(IllegalArgumentException.class, () -> PriceQuote.parse("1000000000000.01"));
    }
}

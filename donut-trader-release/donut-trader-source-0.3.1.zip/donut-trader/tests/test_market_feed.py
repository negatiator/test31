import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("market_feed", Path(__file__).resolve().parents[1] / "tools/market.py")
feed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(feed)
NOW = 1_800_000_000_000

def rows():
    return [{"item": {"id": "minecraft:diamond", "count": 64}, "price": 1_280_000,
             "unixMillisDateSold": NOW - 1000 * (i + 1), "seller": {"uuid": str(i)}} for i in range(5)]

class FeedTest(unittest.TestCase):
    def test_normalizes_stack_total(self):
        q = feed.summarize(rows(), NOW)["quotes"][0]
        self.assertEqual(q["unitSalePrice"], 20000)
        self.assertEqual(q["sampleCount"], 5)
    def test_stale_sales_never_freshened_by_fetch(self):
        self.assertEqual(feed.summarize(rows(), NOW + feed.MAX_AGE_MS)["quotes"], [])
    def test_duplicate_sales_do_not_inflate_samples(self):
        self.assertEqual(feed.summarize([rows()[0]] * 20, NOW)["quotes"], [])
    def test_future_sales_rejected(self):
        self.assertEqual(feed.summarize(rows(), NOW - 100000)["quotes"], [])
    def test_custom_variants_and_bad_counts_excluded(self):
        for field, value in [("lore", ["Special"]), ("contents", [{"id": "diamond"}]),
                             ("enchants", {"enchantments": {"levels": {"fortune": 3}}}),
                             ("display_name", "Custom Diamond"), ("count", 0), ("count", True)]:
            data = rows()
            for r in data: r["item"][field] = value
            self.assertEqual(feed.summarize(data, NOW)["quotes"], [], field)
    def test_outlier_and_invalid_prices(self):
        data = rows(); data[-1]["price"] = 99_000_000
        self.assertEqual(feed.summarize(data, NOW)["quotes"][0]["unitSalePrice"], 20000)
        for price in ["NaN", "Infinity", -1, 0]:
            data = rows()
            for r in data: r["price"] = price
            self.assertEqual(feed.summarize(data, NOW)["quotes"], [])
    def test_bad_rows_ignored(self):
        self.assertEqual(feed.summarize([None, {}, {"item": None}], NOW)["quotes"], [])
    def test_atomic_snapshot_write(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "config/feed.json"
            data = feed.summarize(rows(), NOW); feed.save(target, data)
            self.assertEqual(json.loads(target.read_text()), data)

if __name__ == "__main__": unittest.main()

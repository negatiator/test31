# Donut Trader 0.3.0 — Fabric 1.21.11

Minecraft Java **1.21.11 / Java 21** için otomatik auction istemcisi. Önceki Donut Trader JAR'ını kaldırıp yeni JAR'ı `mods` klasörüne koyun. Fabric Loader **0.19.5+** ve 1.21.11 Fabric API gerekir.

## Kullanım

- **Sağ Shift**, `/dt` veya `/dt ui`: kontrol paneli.
- **`/dt auto`** veya panelde **AUTO aç**: eşya arama, sayfa tarama, fırsat alışını ve yeniden ilan akışını başlatır.
- **`/dt stop`**: durdurur. **`/dt status`**: aşama, sayfa/ilan sayısı, bütçe ve neden beklediği. **`/dt market`**: veri kaynakları.
- **`/dt reload`**: durdurup ayarları okur. `/dt start` yalnızca gözlemdir ve AUTO'yu kapatır.

Panelde **Özet, Fırsatlar, Filtreler, Geçmiş** sekmeleri bulunur. Fırsat satırları görüldükten sonra 60 saniye tutulur; işlem öncesinde gerçek ekran yeniden okunur. Filtreler standart eşyaları etkinleştirir veya engeller; değişiklik AUTO'yu durdurur. Panel açıkken yeni işlem tıklanmaz. Devam eden bir ekonomik işlemin ortasında panel açılmaz; `/dt status` kullanılabilir. Panel kapanınca arama yeniden açılır. Oyun açıldığında AUTO başlamaz.

## Gonuts ve video ile ilişkisi

Kullanıcının paylaştığı [Gonuts](https://github.com/cody-raves/Gonuts) incelendi. Güncel upstream `1f7712fce7e7f01288e099790c1409dbf2e57b1c`, Minecraft **26.2 / Java 25** hedefliyor. Bu proje upstream'in tüm istemcisinin portu değildir: mevcut 1.21.11 istemcisine kontrol paneli, kara liste, kalıcı işlem geçmişi, satış istatistikleri ve kaynak kesintisinde canlı ilan karşılaştırması eklendi.

Gonuts'un bağımsız Java 21 `dev.doughbay.core.stats.RobustStats` sınıfı MIT lisansıyla dahil edildi. Log-fiyat MAD ayıklaması ve MAD/çeyreklik dağılım ölçümü kullanılıyor. Telif ve lisans JAR içinde `GONUTS-NOTICE.txt` ve `licenses/Gonuts-MIT.txt` dosyalarındadır. Upstream'in 26.2 GUI'si, Swarm, Discord, proxy veya StaffWatch bileşenleri bu JAR'a dahil edilmedi; dışarıya gözlem/hesap verisi yüklenmez.

Raindots videosunun anlatımındaki gerçekleşmiş satış verisi, resmi API'ye bağlıdır. Yayımlanan README ve video `/api` erişiminin DONUT+ gerektirdiğini belirtiyor. Bu sürüm anahtarsız kullanım için sahte satış/talep verisi üretmez.

## Fiyat kaynakları ve karar

1. **Canlı auction ekranı:** API gerekmez. En az beş aynı bileşen/adette diğer ilan, alt çeyrek fiyatı, %1 aşağı hedef, en az %10 varsayılan ücret ve %15 tahmini net marj aranır. MAD ve çeyreklik yayılımı %30'u aşan dengesiz akran dağılımında işlem yapılmaz. Bunlar ilanlardır; gerçekleşmiş satış veya gerçek talep kanıtı sayılmaz. Dış referans yokken bot bu kaynağı kullanır ve bunu fırsat satırında açıkça yazar.
2. **Herkese açık web referansı:** [DonutSMP Terminal JSON](https://donutsmpterminal.com/snapshots/latest.json), `items[id]` dizisinin üçüncü AH birim fiyatı. Beş dakikada bir arka planda yenilenir; dosyanın `captured` tarihinden altı saat sonra kullanılmaz. Uygun olduğunda hedefi yalnızca aşağı sınırlar. Erişim engeli veya eski dosya yeni bir tarih gibi gösterilmez. 21 Ekim 2026 son kontrolde HTTP403 döndüğü için canlı web fiyatları doğrulanamadı; bu durum canlı ekran taramasını engellemez.
3. **İsteğe bağlı gerçek satış API'si:** Anahtar varsa `GET https://api.donutsmp.net/v1/auction/transactions/{page}`, 1–10 sayfa, 30 saniyede en fazla bir istek. Resmi Swagger sözleşmesine göre Bearer kullanılır. Paneldeki **DONUT+ API: panodan ekle** anahtarı yalnızca yerel dosyaya kaydeder. Sohbete veya loglara yazılmaz. `config/donut-trader-api-key.txt` veya mevcut `config/donut-flip-scanner/api-key.txt` başlangıçta okunabilir. Anahtar zorunlu değildir.

API istatistiği için son üç gün içinde en az beş kabul edilen farklı satış, en az üç farklı satıcı ve son altı saatte kabul edilen bir satış gerekir. Bilinmeyen özel eşya bileşenleri, lore, enchantment, gelecekteki kayıtlar ve yinelenen sayfa kayıtları reddedilir. Gonuts MAD ayıklamasından sonra minimum örnek sayısı yeniden kontrol edilir. Muhafazakâr birim değer `min(P40, zamana ağırlıklı medyan)` olarak aşağı yuvarlanır; oynaklık %30'u aşarsa o eşya bekletilir. Yeterli satış verisi, ince bir canlı sayfayı fiyatlandırabilir; canlı akranlar ve taze web referansı hedefi yalnızca aşağı sınırlar. `örnek/saat`, toplanmış örneklerin hızıdır; tüm pazarın gerçek likiditesi değildir.

API analizi ağ çalışanında yapılır; GUI'de tekrar tekrar büyük geçmiş hesaplanmaz. Başarılı son API okuması 90 saniyeden eskiyse satış referansı devre dışı kalır. En fazla 10.000 satış yerel saklanır; yeniden başlatmada bir sonraki başarılı API isteğine kadar bu disk geçmişi tek başına alım açmaz. Gerçek anahtarla HTTP/oyun entegrasyonu bu ortamda test edilmedi.

## Bütçe ve işlem kanıtı

Toplam kümülatif alış limiti **10.000.000 coin**; asgari **tahmini** net marj **%15**. AUTO ücret hesabını en az **%10** varsayar; bu gerçek sunucu ücretinin kanıtı değildir. Satış gelirleri bütçeyi otomatik büyütmez.

Tutarlar 0,01 coin biriminde hesaplanır. `$24.9` tamdır; `$2.5M` gibi kısa etiketlerde belirsizlik aralığının üst sınırı bütçeye ayrılır, akran fiyatında alt sınır kullanılır. Doğrudan teslimde kesin hesap kesintisi bağımsız ölçülmez: bütçe, görünen ilanın ayrılan üst sınırını izler. İşlem anında değişen sunucu fiyatı ve gerçek ücretler farklı olabilir.

Alış tıklamasından önce `config/donut-trader-ledger.json` atomik kaydedilir. Tam eşya/adet/fiyat eşleşmesi ve yerel Minecraft onayı kontrol edilir. Teslim ve hızlı erişim taşıması gerçek sunucu envanter güncellemesi gerektirir. Satış komutundan sonra envanterden kaybolma yeterli değildir: **Your Items** içinde yeni tekil eşya/adet/fiyat kaydı aranır. Aynı eşyadan mevcut envanter veya aktif kişisel ilan karışmayı önlemek için atlanır. Çok sayfalı kişisel ilan veya belirsiz ekran/işlem durumunda durur. Belirsiz işlem defteri otomatik temizlenmez.

`config/donut-trader-history.json`, doğrulanan ilanları ve ayrılma/durma kayıtlarını saklar. Paneldeki grafik **ilanların tahmini net kârıdır**; gerçekleşmiş satış veya kazanılmış para değildir. Bir ilan açılması, satıldığı anlamına gelmez. Bütçe ve geçmiş dosyaları ayrıdır; geçmiş hatası bütçeyi sıfırlamaz. Eski coin defterleri bir kez dönüştürülür; defteri silmek takip edilen bütçeyi sıfırlar ve önerilmez.

## Derleme ve doğrulama

Java 21 JDK ile `./gradlew build`, Windows'ta `gradlew.bat build`. Bulut yardımcı komutu `python3 tools/build.py build`; TLS ve Gradle dağıtım checksum kontrolü korunur. Loom1.14.10 / Gradle9.2.1 / Fabric Loader0.19.5 sabittir.

0.3.0 için 80 test geçti: tam ve kısa para etiketleri, bütçe göçü, gerçek 45-ilan düzeni, onay diyaloğu/teslim kanıtları, muhafazakâr API örnekleri ve tekrarları, uç fiyatlar/satıcı yoğunluğu, kaynak yokluğu, oynaklık, komisyon sonrası marj ve kalıcı işlem günlüğü. Minecraft/Fabric derlemesi tamamlandı. Bu ortamda gerçek hesapla DonutSMP alış/satışı veya GUI'nin ekranda çalıştırılması denenmedi. Kâr garantisi yoktur.

Eski `/dt profile`, `/dt local`, `/dt inspect`, `/dt inspect confirm` ve `/dt arm` teşhis/manuel mod için korunur; AUTO bunları gerektirmez.

package dev.donuttrader;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.KeyEvent;
import org.lwjgl.glfw.GLFW;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** A view of actual runner evidence. Opening this screen never creates market data. */
public final class TraderDashboard extends Screen {
    public record Offer(String itemId, int count, long buyMinor, long sellMinor,
                        long estimatedProfitMinor, String evidence, long seenMillis) {}
    public record Event(long atMillis, String message, long cumulativeEstimatedProfitMinor) {}
    public record Snapshot(boolean active, String phase, String target, String reason,
                           long scannedPages, long scannedListings, long budgetMinor, long reservedMinor,
                           int listings, long estimatedProfitMinor, List<Offer> offers, List<Event> events,
                           String webStatus, String salesStatus, List<String> filters, Set<String> blocked) {
        public Snapshot {
            offers = List.copyOf(offers); events = List.copyOf(events);
            filters = List.copyOf(filters); blocked = Set.copyOf(blocked);
        }
    }
    public interface Controller {
        Snapshot snapshot();
        void start();
        void stop();
        void toggleBlocked(String itemId);
        void setApiKeyFromClipboard();
    }

    private enum Tab {
        OVERVIEW("Özet"), OFFERS("Fırsatlar"), FILTERS("Filtreler"), HISTORY("Geçmiş");
        final String label;
        Tab(String label) { this.label = label; }
    }
    private static final int BG = 0xff0d121c, CARD = 0xff151e2b, BORDER = 0xff28384b;
    private static final int TEXT = 0xffe7eef6, MUTED = 0xff91a1b6, GREEN = 0xff62ddac;
    private static final int BLUE = 0xff75b5ff, AMBER = 0xffffce80;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss")
            .withZone(ZoneId.systemDefault());
    private final Controller controller;
    private Tab tab = Tab.OVERVIEW;
    private int page, left, top, panelWidth, panelHeight, bodyX, bodyY, bodyWidth, bodyHeight;
    private Button start, stop;

    public TraderDashboard(Controller controller) {
        super(Component.literal("Donut Trader"));
        this.controller = controller;
    }

    @Override protected void init() {
        panelWidth = Math.max(220, Math.min(820, width - 24));
        panelHeight = Math.max(190, Math.min(500, height - 24));
        left = (width - panelWidth) / 2; top = (height - panelHeight) / 2;
        bodyX = left + 12; bodyY = top + 76;
        bodyWidth = panelWidth - 24; bodyHeight = panelHeight - 100;
        int startWidth = panelWidth < 400 ? 68 : 91;
        int stopWidth = panelWidth < 400 ? 50 : 70;
        start = button(left + panelWidth - startWidth - stopWidth - 44, top + 10,
                startWidth, 22, "AUTO aç", GREEN, () -> {
                    minecraft.setScreen(null);
                    controller.start();
                });
        stop = button(left + panelWidth - stopWidth - 38, top + 10, stopWidth, 22,
                "Durdur", AMBER, controller::stop);
        button(left + panelWidth - 30, top + 10, 20, 22, "×", MUTED, this::onClose);
        int tabWidth = (panelWidth - 24) / Tab.values().length;
        for (int i = 0; i < Tab.values().length; i++) {
            Tab value = Tab.values()[i];
            button(left + 12 + i * tabWidth, top + 44, tabWidth - 4, 23,
                    value.label, tab == value ? BLUE : MUTED, () -> {
                        tab = value; page = 0; rebuildWidgets();
                    });
        }
        Snapshot s = controller.snapshot();
        if (tab == Tab.FILTERS) {
            int count = filterPageSize();
            page = Math.min(page, Math.max(0, (s.filters().size() - 1) / count));
            int begin = page * count;
            for (int i = begin; i < Math.min(s.filters().size(), begin + count); i++) {
                String id = s.filters().get(i);
                int rowY = bodyY + 25 + (i - begin) * 27;
                boolean blocked = s.blocked().contains(id);
                button(bodyX + bodyWidth - 83, rowY - 3, 79, 21,
                        blocked ? "Engelli" : "İzinli", blocked ? AMBER : GREEN, () -> {
                            controller.toggleBlocked(id); rebuildWidgets();
                        });
            }
        }
        if (tab != Tab.OVERVIEW) {
            button(bodyX, bodyY + bodyHeight - 21, 36, 20, "<", MUTED, () -> {
                page = Math.max(0, page - 1); rebuildWidgets();
            });
            button(bodyX + 42, bodyY + bodyHeight - 21, 36, 20, ">", MUTED, () -> {
                page = Math.min(maxPage(controller.snapshot()), page + 1); rebuildWidgets();
            });
        } else {
            button(bodyX + bodyWidth - Math.min(192, bodyWidth), bodyY + bodyHeight - 21,
                    Math.min(192, bodyWidth), 20, "DONUT+ API: panodan ekle", BLUE,
                    controller::setApiKeyFromClipboard);
        }
    }

    private Button button(int x, int y, int w, int h, String title, int color, Runnable action) {
        return addRenderableWidget(new FlatButton(x, y, w, h, title, color, action));
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        Snapshot s = controller.snapshot();
        g.fill(0, 0, width, height, 0xb9000000);
        g.fill(left + 3, top + 4, left + panelWidth + 3, top + panelHeight + 4, 0x80000000);
        g.fill(left, top, left + panelWidth, top + panelHeight, BG);
        g.renderOutline(left, top, panelWidth, panelHeight, BORDER);
        g.fill(left, top, left + panelWidth, top + 2, GREEN);
        int titleSpace = start.getX() - left - 20;
        label(g, "DONUT TRADER", left + 13, top + 12, titleSpace, TEXT);
        if (panelWidth > 410) label(g, s.active() ? "AUTO  /  " + s.phase() : "DURDU", left + 13, top + 26,
                titleSpace, s.active() ? GREEN : MUTED);
        start.active = !s.active(); stop.active = s.active();
        switch (tab) {
            case OVERVIEW -> overview(g, s, mouseX, mouseY);
            case OFFERS -> offers(g, s, mouseX, mouseY);
            case FILTERS -> filters(g, s);
            case HISTORY -> history(g, s, mouseX, mouseY);
        }
        label(g, "Sağ Shift / Esc: kapat  ·  Veriler ve kâr tahminidir", left + 12,
                top + panelHeight - 14, panelWidth - 24, MUTED);
        super.render(g, mouseX, mouseY, delta);
    }

    private void overview(GuiGraphics g, Snapshot s, int mouseX, int mouseY) {
        boolean compact = bodyHeight < 235;
        int gap = 7, cardWidth = (bodyWidth - gap) / 2;
        int cardHeight = compact ? 32 : 43;
        metric(g, bodyX, bodyY, cardWidth, cardHeight, "Ayrılan alış / limit",
                money(s.reservedMinor()) + " / " + money(s.budgetMinor()), BLUE);
        metric(g, bodyX + cardWidth + gap, bodyY, cardWidth, cardHeight,
                "İlanların tahmini net kârı", "+" + money(s.estimatedProfitMinor()), GREEN);
        int y = bodyY + cardHeight + 7;
        String stats = s.scannedPages() + " sayfa  ·  " + s.scannedListings() + " ilan tarandı  ·  "
                + s.listings() + " yeniden ilan";
        label(g, stats, bodyX, y, bodyWidth, MUTED); y += 16;
        label(g, (s.active() ? s.phase() : "DURDU") + "  ·  " + itemName(s.target()),
                bodyX, y, bodyWidth, TEXT); y += 14;
        int reasonLines = compact ? 1 : 2;
        wrapped(g, s.reason(), bodyX, y, bodyWidth, reasonLines, AMBER, mouseX, mouseY);
        y += reasonLines * 11 + 9;
        if (compact) {
            if(y+10<bodyY+bodyHeight-25) {
                wrapped(g,s.webStatus(),bodyX,y,bodyWidth,1,MUTED,mouseX,mouseY);y+=12;
            }
            if(y+10<bodyY+bodyHeight-25)wrapped(g,s.salesStatus(),bodyX,y,bodyWidth,1,MUTED,mouseX,mouseY);
            return;
        }
        int sourceWidth = bodyWidth > 540 ? Math.min(340, bodyWidth / 2 - 8) : bodyWidth;
        int sourceHeight = Math.max(52, Math.min(89, bodyY + bodyHeight - 28 - y));
        g.fill(bodyX, y, bodyX + sourceWidth, y + sourceHeight, CARD);
        label(g, "FİYAT KAYNAKLARI", bodyX + 9, y + 8, sourceWidth - 18, BLUE);
        wrapped(g, s.webStatus(), bodyX + 9, y + 25, sourceWidth - 18, 2, MUTED, mouseX, mouseY);
        wrapped(g, s.salesStatus(), bodyX + 9, y + 49, sourceWidth - 18,
                Math.max(1, (sourceHeight - 53) / 10), MUTED, mouseX, mouseY);
        if (sourceWidth < bodyWidth) {
            int chartX = bodyX + sourceWidth + 9;
            chart(g, s.events(), chartX, y, bodyWidth - sourceWidth - 9, sourceHeight);
        } else if (bodyY + bodyHeight - y - sourceHeight > 85) {
            chart(g, s.events(), bodyX, y + sourceHeight + 8, bodyWidth,
                    bodyY + bodyHeight - 29 - y - sourceHeight - 8);
        }
    }

    private void metric(GuiGraphics g, int x, int y, int w, int h, String title, String value, int color) {
        g.fill(x, y, x + w, y + h, CARD);
        g.fill(x, y, x + 2, y + h, color);
        label(g, title, x + 8, y + 6, w - 16, MUTED);
        label(g, value, x + 8, y + h - 13, w - 16, color);
    }

    private void offers(GuiGraphics g, Snapshot s, int mouseX, int mouseY) {
        label(g, "Görülen fırsatlar · güncel fiyat tıklamadan önce tekrar doğrulanır", bodyX, bodyY,
                bodyWidth, MUTED);
        int size = offerPageSize();
        page = Math.min(page, maxPage(s));
        if (s.offers().isEmpty()) {
            empty(g, "Henüz uygun fırsat görülmedi.", "Tarama ve veri durumu Özet sekmesinde.");
        } else {
            int begin = page * size;
            for (int i = begin; i < Math.min(s.offers().size(), begin + size); i++) {
                Offer o = s.offers().get(i); int y = bodyY + 19 + (i - begin) * 68;
                g.fill(bodyX, y, bodyX + bodyWidth, y + 62, CARD);
                label(g, itemName(o.itemId()) + " ×" + o.count(), bodyX + 9, y + 7,
                        bodyWidth - 85, TEXT);
                label(g, elapsed(o.seenMillis()), bodyX + bodyWidth - 72, y + 7, 64, MUTED);
                double roi = o.buyMinor() > 0 ? 100.0 * o.estimatedProfitMinor() / o.buyMinor() : 0;
                label(g, "Alış ≤ " + money(o.buyMinor()) + "   Hedef " + money(o.sellMinor()),
                        bodyX + 9, y + 23, bodyWidth - 18, BLUE);
                label(g, "Tahmini net +" + money(o.estimatedProfitMinor()) + "  ("
                                + String.format(Locale.ROOT, "%.1f", roi) + "%)", bodyX + 9, y + 36,
                        bodyWidth - 18, GREEN);
                wrapped(g, o.evidence(), bodyX + 9, y + 49, bodyWidth - 18, 1, MUTED, mouseX, mouseY);
            }
        }
        pagination(g, s);
    }

    private void filters(GuiGraphics g, Snapshot s) {
        label(g, "İzinli eşyalar aranır; filtre değişikliği AUTO'yu durdurur.", bodyX, bodyY,
                bodyWidth, MUTED);
        int begin = page * filterPageSize();
        for (int i = begin; i < Math.min(s.filters().size(), begin + filterPageSize()); i++) {
            int y = bodyY + 25 + (i - begin) * 27;
            g.fill(bodyX, y - 4, bodyX + bodyWidth - 89, y + 19, CARD);
            label(g, itemName(s.filters().get(i)), bodyX + 8, y + 2, bodyWidth - 110,
                    s.blocked().contains(s.filters().get(i)) ? MUTED : TEXT);
        }
        if (s.filters().isEmpty()) empty(g, "Eşya listesi boş.", "AUTO standart eşya listesini hazırlayacak.");
        pagination(g, s);
    }

    private void history(GuiGraphics g, Snapshot s, int mouseX, int mouseY) {
        label(g, "İşlem günlüğü · ilan doğrulanması, gerçekleşmiş satış değildir", bodyX, bodyY,
                bodyWidth, MUTED);
        if (s.events().isEmpty()) empty(g, "Henüz işlem kaydı yok.", "Gerçek işlemler burada görünecek.");
        int size = historyPageSize(), begin = page * size;
        page = Math.min(page, maxPage(s));
        begin = page * size;
        for (int i = begin; i < Math.min(s.events().size(), begin + size); i++) {
            Event e = s.events().get(i); int y = bodyY + 20 + (i - begin) * 33;
            g.fill(bodyX, y, bodyX + bodyWidth, y + 29, CARD);
            label(g, time(e.atMillis()), bodyX + 7, y + 5, 55, MUTED);
            wrapped(g, e.message(), bodyX + 65, y + 5, bodyWidth - 73, 2, TEXT, mouseX, mouseY);
        }
        pagination(g, s);
    }

    private void chart(GuiGraphics g, List<Event> events, int x, int y, int w, int h) {
        if (h < 55 || w < 100) return;
        g.fill(x, y, x + w, y + h, CARD);
        label(g, "İlanların tahmini kârı", x + 8, y + 7, w - 16, MUTED);
        List<Event> points = events.stream().sorted(java.util.Comparator.comparingLong(Event::atMillis)).toList();
        if (points.size() < 2) {
            label(g, "Grafik için işlem bekleniyor", x + 8, y + 29, w - 16, MUTED);
            return;
        }
        int x0 = x + 10, x1 = x + w - 10, y0 = y + 24, y1 = y + h - 15;
        long max = points.stream().mapToLong(Event::cumulativeEstimatedProfitMinor).max().orElse(0);
        if (max <= 0) {
            label(g, "Doğrulanan ilan kârı henüz yok", x + 8, y + 29, w - 16, MUTED);
            return;
        }
        g.hLine(x0, x1, y1, BORDER);
        for (int i = 1; i < points.size(); i++) {
            int ax = x0 + (x1 - x0) * (i - 1) / (points.size() - 1);
            int bx = x0 + (x1 - x0) * i / (points.size() - 1);
            int ay = y1 - (int) ((y1 - y0) * (double) Math.max(0, points.get(i - 1).cumulativeEstimatedProfitMinor()) / max);
            int by = y1 - (int) ((y1 - y0) * (double) Math.max(0, points.get(i).cumulativeEstimatedProfitMinor()) / max);
            line(g, ax, ay, bx, by, GREEN);
        }
        label(g, "Gerçekleşmiş kâr değil", x + 8, y + h - 11, w - 16, MUTED);
    }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= steps; i++) {
            int x = steps == 0 ? x0 : x0 + (x1 - x0) * i / steps;
            int y = steps == 0 ? y0 : y0 + (y1 - y0) * i / steps;
            g.fill(x, y, x + 1, y + 1, color);
        }
    }
    private void empty(GuiGraphics g, String title, String detail) {
        int y = bodyY + Math.min(60, bodyHeight / 3);
        label(g, title, bodyX + 10, y, bodyWidth - 20, TEXT);
        label(g, detail, bodyX + 10, y + 17, bodyWidth - 20, MUTED);
    }
    private void pagination(GuiGraphics g, Snapshot s) {
        label(g, (page + 1) + " / " + (maxPage(s) + 1), bodyX + 89,
                bodyY + bodyHeight - 15, bodyWidth - 90, MUTED);
    }
    private int maxPage(Snapshot s) {
        int total = switch (tab) {
            case OFFERS -> s.offers().size(); case FILTERS -> s.filters().size();
            case HISTORY -> s.events().size(); case OVERVIEW -> 0;
        };
        int size = switch (tab) {
            case OFFERS -> offerPageSize(); case FILTERS -> filterPageSize();
            case HISTORY -> historyPageSize(); case OVERVIEW -> 1;
        };
        return Math.max(0, (total - 1) / size);
    }
    private int offerPageSize() { return Math.max(1, (bodyHeight - 43) / 68); }
    private int filterPageSize() { return Math.max(1, (bodyHeight - 51) / 27); }
    private int historyPageSize() { return Math.max(1, (bodyHeight - 43) / 33); }
    private void label(GuiGraphics g, String text, int x, int y, int maxWidth, int color) {
        if (maxWidth <= 0) return;
        g.drawString(font, fit(text, maxWidth), x, y, color, false);
    }
    private String fit(String text, int maxWidth) {
        if (text == null) return "";
        if (font.width(text) <= maxWidth) return text;
        return font.plainSubstrByWidth(text, Math.max(0, maxWidth - font.width("…"))) + "…";
    }
    private void wrapped(GuiGraphics g, String text, int x, int y, int maxWidth, int maxLines,
                         int color, int mouseX, int mouseY) {
        if (text == null || maxWidth <= 0 || maxLines <= 0) return;
        var lines = font.split(Component.literal(text), maxWidth);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++)
            g.drawString(font, lines.get(i), x, y + i * 10, color, false);
        if (mouseX >= x && mouseX < x + maxWidth && mouseY >= y && mouseY < y + maxLines * 10)
            g.setTooltipForNextFrame(font, font.split(Component.literal(text), Math.min(420, width - 24)), mouseX, mouseY);
    }
    private static String money(long minor) { return Market.formatMinor(minor); }
    private static String itemName(String id) {
        if (id == null || id.isBlank()) return "Tarama bekleniyor";
        return id.replace("minecraft:", "").replace('_', ' ');
    }
    private static String elapsed(long seen) {
        long age = Math.max(0, (System.currentTimeMillis() - seen) / 1000);
        return age < 60 ? age + " sn önce" : age / 60 + " dk önce";
    }
    private static String time(long epochMillis) {
        try { return TIME.format(Instant.ofEpochMilli(epochMillis)); }
        catch (RuntimeException invalid) { return "--:--:--"; }
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean keyPressed(KeyEvent event) {
        if(event.key()==GLFW.GLFW_KEY_RIGHT_SHIFT){onClose();return true;}
        return super.keyPressed(event);
    }

    private final class FlatButton extends Button {
        private final int color;
        private FlatButton(int x, int y, int w, int h, String text, int color, Runnable action) {
            super(x, y, w, h, Component.literal(text), ignored -> action.run(), DEFAULT_NARRATION);
            this.color = color;
        }
        @Override protected void renderContents(GuiGraphics g, int mouseX, int mouseY, float delta) {
            g.fill(getX(), getY(), getRight(), getBottom(), isHoveredOrFocused() ? 0xff26374b : CARD);
            g.renderOutline(getX(), getY(), getWidth(), getHeight(),
                    isHoveredOrFocused() && active ? color : BORDER);
            String text = fit(getMessage().getString(), getWidth() - 8);
            g.drawCenteredString(font, text, getX() + getWidth() / 2,
                    getY() + (getHeight() - 8) / 2, active ? color : 0xff546173);
        }
    }
}

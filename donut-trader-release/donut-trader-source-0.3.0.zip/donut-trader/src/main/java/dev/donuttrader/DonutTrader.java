package dev.donuttrader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.Command;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/** Single transaction at a time; no retries of ambiguous purchases or sales. */
public final class DonutTrader implements ClientModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DIR = FabricLoader.getInstance().getConfigDir();
    private static final Path CONFIG = DIR.resolve("donut-trader.json");
    private static final Path LEDGER = DIR.resolve("donut-trader-ledger.json");
    private enum Phase { SCAN, CONFIRM, RECEIVE, SELL }
    private Config cfg;
    private SpendLedger ledger;
    private boolean running, armed;
    private Phase phase = Phase.SCAN;
    private int ticks, deadline, oldHotbar;
    private Market.Deal pending;
    private String lastOffer = "";
    private String lastScan = "";
    private List<String> lastInspection = List.of();
    private List<String> lastNonListingInspection = List.of();
    private final WebMarket webMarket = new WebMarket();
    private final OfficialMarket officialMarket = new OfficialMarket(DIR);
    private final TradingJournal journal = new TradingJournal(DIR.resolve("donut-trader-history.json"));
    private AutoTrader auto;
    private boolean openPanelRequested;
    private KeyMapping panelKey;

    @Override public void onInitializeClient() {
        reload();
        panelKey=KeyBindingHelper.registerKeyBinding(new KeyMapping("key.donuttrader.dashboard",
                InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_RIGHT_SHIFT,KeyMapping.Category.MISC));
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
            literal("dt")
                .executes(c->{openPanelRequested=true;return 1;})
                .then(literal("ui").executes(c->{openPanelRequested=true;return 1;}))
                .then(literal("start").executes(c -> { if (auto != null && auto.active()) auto.stop("Manuel gözleme geçildi."); if (phase != Phase.SCAN) { say("Bekleyen işlem var. Elle kontrol ettikten sonra /dt reload kullan."); return 0; } running = true; armed = false; ticks = 0; say("Gözlem açık; otomatik işlem kapalı."); return Command.SINGLE_SUCCESS; }))
                .then(literal("stop").executes(c -> { halt("Durduruldu."); return 1; }))
                .then(literal("arm").executes(c -> { arm(); return 1; }))
                .then(literal("auto").executes(c -> startAuto()))
                .then(literal("profile").executes(c -> {
                    if (auto != null && auto.active()) auto.stop("Manuel profil düzenlemesine geçildi.");
                    if (phase != Phase.SCAN) { say("Bekleyen işlem var; önce elle kontrol et."); return 0; }
                    running = armed = false;
                    AuctionProfile.apply(cfg);
                    try {
                        cfg.validate(); atomicWrite(CONFIG, cfg);
                        say("Auction liste profili kaydedildi: slot 0–44, $ fiyatları. /dt start gözlem açar; alış onayı ve komisyon henüz doğrulanmadı.");
                        return 1;
                    } catch (Exception error) { say("Profil kaydedilemedi; otomatik işlem kapalı."); return 0; }
                }))
                .then(literal("local").executes(c -> {
                    if (auto != null && auto.active()) auto.stop("Manuel ayarlara geçildi.");
                    if (phase != Phase.SCAN) { say("Bekleyen işlem var; önce elle kontrol et."); return 0; }
                    running = armed = false;
                    try {
                        cfg.requireRecentSales = false;
                        atomicWrite(CONFIG, cfg);
                        say("API gerektirmeyen ilan modu kaydedildi. /dt start gözlem açar; satış ve kâr doğrulanmaz.");
                        return 1;
                    } catch (IOException error) { say("Ayar kaydedilemedi; otomatik işlem kapalı."); return 0; }
                }))
                .then(literal("status").executes(c -> { if (auto != null && auto.active()) say(auto.status()); else say("Çalışıyor=" + running + " otomatik=" + armed + " durum=" + phase + " ayrılan bütçe=" + Market.formatMinor(ledger.committed) + "/" + cfg.budget + " belirsiz=" + ledger.unresolved); return 1; }))
                .then(literal("inspect").executes(c -> { inspect(false); return 1; })
                    .then(literal("confirm").executes(c -> { inspect(true); return 1; })))
                .then(literal("market").executes(c -> {
                    long now = System.currentTimeMillis();
                    webMarket.refresh(now);
                    say(webMarket.status(now) + "; web sınırı=" + cfg.useWebReference);
                    officialMarket.refresh(now);say(officialMarket.status(now));
                    if (cfg.requireRecentSales) say("Güncel gerçekleşmiş satış referansı: " + SalesFeed.read(DIR.resolve("donut-trader-market.json"), now).size());
                    return 1;
                }))
                .then(literal("reload").executes(c -> { halt("Yapılandırma yeniden okunuyor."); reload(); return 1; }))
        ));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            captureScreen(mc);
            while(panelKey.consumeClick())openPanelRequested=true;
            if(openPanelRequested){openPanelRequested=false;openDashboard(mc);}
            if (cfg.useWebReference && mc.player != null && onServer(mc)) webMarket.refresh(System.currentTimeMillis());
            if(mc.player!=null&&onServer(mc))officialMarket.refresh(System.currentTimeMillis());
            if (auto != null && auto.active()) { auto.tick(mc); return; }
            if (!running) return;
            try { tick(mc); }
            catch (Exception e) { halt("İşlem durdu: " + e.getClass().getSimpleName() + " " + e.getMessage()); }
        });
    }

    private int startAuto() {
        halt("Tek komutlu AUTO hazırlanıyor.");
        if(phase!=Phase.SCAN){say("Önceki manuel işlem bekliyor; otomatik tekrar yapılmaz.");return 0;}
        if(!onServer(Minecraft.getInstance())){say("Önce DonutSMP sunucusuna bağlan.");return 0;}
        try {
            cfg.requireRecentSales=false;
            auto=new AutoTrader(cfg,ledger,webMarket,officialMarket,journal,LEDGER);
            atomicWrite(CONFIG,cfg);
            journal.event("AUTO basladi; toplam alis limiti "+cfg.budget+", tahmini net esik %"+Math.round(cfg.minNetMargin*100));
            return 1;
        }catch(Exception error){if(auto!=null)auto.stop("AUTO başlamadı: "+error.getMessage());else say(error.getMessage());return 0;}
    }
    private void openDashboard(Minecraft mc) {
        if(mc.screen instanceof TraderDashboard){mc.setScreen(null);return;}
        if((!ledger.unresolved.isBlank()&&auto!=null&&auto.active()) || (running&&phase!=Phase.SCAN)) {
            say("Islem suruyor; panel yeni islem bitince acilir. /dt status ile durum gorulur.");return;
        }
        if(mc.player!=null) {
            if(!mc.player.containerMenu.getCarried().isEmpty()){say("Once imlecteki esyayi yerlestir.");return;}
            if(mc.screen instanceof AbstractContainerScreen<?>)mc.player.closeContainer();
            else if(mc.screen!=null&&!(mc.screen instanceof net.minecraft.client.gui.screens.ChatScreen)){
                say("Panel icin mevcut ekrani kapat.");return;
            }
        }
        mc.setScreen(new TraderDashboard(new TraderDashboard.Controller() {
            @Override public TraderDashboard.Snapshot snapshot() {
                long now=System.currentTimeMillis();
                var filters=new TreeSet<String>(cfg.allowedItems);
                for(String id:AutoPolicy.WATCH)filters.add("minecraft:"+id);
                filters.addAll(cfg.blockedItems);
                var blocked=new HashSet<String>(cfg.blockedItems);
                if(!cfg.allowedItems.isEmpty())for(String id:filters)if(!cfg.allowedItems.contains(id))blocked.add(id);
                String reason=auto==null?"AUTO acilinca gercek ilanlar taranir":auto.reason();
                if(!ledger.unresolved.isBlank())reason="Belirsiz islem: "+ledger.unresolved;
                if(!journal.storageStatus().isBlank())reason+=" | "+journal.storageStatus();
                return new TraderDashboard.Snapshot(auto!=null&&auto.active(),auto==null?"HAZIR":auto.phase(),
                    auto==null?"":auto.target(),reason,auto==null?0:auto.scannedPages(),auto==null?0:auto.scannedListings(),
                    Market.toMinor(cfg.budget),ledger.committed,journal.listings(),journal.estimatedProfitMinor(),
                    auto==null?List.of():auto.offers(now),journal.entries().reversed().stream()
                        .map(e->new TraderDashboard.Event(e.atMillis(),e.message(),e.cumulativeEstimatedProfitMinor())).toList(),
                    webMarket.status(now),officialMarket.status(now),List.copyOf(filters),blocked);
            }
            @Override public void start(){startAuto();}
            @Override public void stop(){halt("Panelden durduruldu.");}
            @Override public void toggleBlocked(String id){
                if(!ledger.unresolved.isBlank()){say("Belirsiz islem varken filtre degistirilmez.");return;}
                halt("Filtre degisti; yeniden baslatmak icin AUTO ac.");
                if(cfg.allowedItems.isEmpty())for(String watched:AutoPolicy.WATCH)cfg.allowedItems.add("minecraft:"+watched);
                if(!cfg.allowedItems.contains(id)){cfg.allowedItems.add(id);cfg.blockedItems.remove(id);}
                else if(!cfg.blockedItems.remove(id))cfg.blockedItems.add(id);
                try{atomicWrite(CONFIG,cfg);}catch(IOException e){say("Filtre kaydedilemedi.");}
            }
            @Override public void setApiKeyFromClipboard(){
                try{String key=mc.keyboardHandler.getClipboard();if(key==null||key.isBlank())throw new IllegalArgumentException("Empty clipboard");
                    officialMarket.setKey(key);say("API anahtari yerel kaydedildi; baglanti deneniyor.");officialMarket.refresh(System.currentTimeMillis());}
                catch(Exception failure){say("Panoda gecerli API anahtari bulunamadi veya dosya kaydedilemedi.");}
            }
        }));
    }

    private void reload() {
        running = armed = false; phase = Phase.SCAN; pending = null; ticks = 0;
        try {
            Files.createDirectories(DIR);
            cfg = Files.exists(CONFIG) ? GSON.fromJson(Files.readString(CONFIG), Config.class) : new Config();
            cfg.validate();
            if (!Files.exists(CONFIG)) atomicWrite(CONFIG, cfg);
            ledger = Files.exists(LEDGER) ? GSON.fromJson(Files.readString(LEDGER), SpendLedger.class) : new SpendLedger();
            if (ledger == null) throw new IOException("Invalid ledger");
            if (ledger.upgrade()) atomicWrite(LEDGER, ledger);
        } catch (Exception e) {
            cfg = new Config(); ledger = new SpendLedger(); ledger.upgrade(); ledger.unresolved = "Yapılandırma/defter okunamadı: " + e.getMessage();
            running = armed = false;
            System.err.println("[DonutTrader] " + ledger.unresolved);
        }
    }
    private static void atomicWrite(Path target, Object value) throws IOException {
        Path temp = Files.createTempFile(target.getParent(), target.getFileName().toString(), ".tmp");
        try {
            Files.writeString(temp, GSON.toJson(value));
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } finally { Files.deleteIfExists(temp); }
    }
    private void arm() {
        if (auto != null && auto.active()) auto.stop("Manuel işlem moduna geçildi.");
        if (!ledger.unresolved.isBlank()) { say("Önce belirsiz işlemi envanter/auction geçmişinden kontrol et: " + ledger.unresolved); return; }
        if (!cfg.canArm()) { say("Profil hazır değil. Ekran, toplam/birim fiyat anlamı, komisyon ve eşya izinleri doğrulanmalı."); return; }
        if (phase != Phase.SCAN) { say("Bekleyen işlem var; yeniden başlatmadan önce kontrol et."); return; }
        if (!onServer(Minecraft.getInstance())) { say("Yalnızca yapılandırılmış DonutSMP sunucusunda çalışır."); return; }
        if (cfg.useWebReference && webMarket.prices(System.currentTimeMillis()).isEmpty()) {
            webMarket.refresh(System.currentTimeMillis());
            say("Web referansı henüz hazır değil veya dosya 6 saatten eski. /dt market ile kontrol et."); return;
        }
        if (cfg.requireRecentSales && SalesFeed.read(DIR.resolve("donut-trader-market.json"), System.currentTimeMillis()).isEmpty()) {
            say("Güncel satış verisi yok. tools/market.py ile piyasa dosyasını güncelle; /dt market ile kontrol et."); return;
        }
        running = armed = true; ticks = 0;
        say("Otomatik işlem açık. Kalan toplam alış limiti: " + Market.formatMinor(Math.max(0, Market.toMinor(cfg.budget) - ledger.committed)));
        if (!cfg.requireRecentSales) say("Fiyat kaynağı: mevcut ilanlar. Gerçekleşmiş satış ve kâr doğrulanmaz.");
    }
    private static void say(String message) {
        var player = Minecraft.getInstance().player;
        if (player != null) player.displayClientMessage(Component.literal("[DonutTrader] " + message), false);
    }
    private void halt(String reason) { running = armed = false; if (auto != null && auto.active()) auto.stop(reason); else say(reason); }
    private boolean onServer(Minecraft mc) {
        var server = mc.getCurrentServer();
        if (server == null) return false;
        String host = server.ip.toLowerCase(Locale.ROOT).split(":", 2)[0];
        String expected = cfg.serverHost.toLowerCase(Locale.ROOT);
        return host.equals(expected) || host.endsWith("." + expected);
    }
    private static String key(ItemStack stack) {
        ItemStack copy = stack.copy(); copy.setCount(1);
        copy.remove(DataComponents.LORE); // Preserve name, enchantments, damage and all other components.
        return BuiltInRegistries.ITEM.getKey(copy.getItem()) + "|" + copy.getComponents();
    }
    private OptionalLong price(ItemStack stack) {
        var lore = stack.get(DataComponents.LORE);
        if (lore == null) return OptionalLong.empty();
        return AuctionProfile.priceMinor(lore.lines().stream().map(Component::getString).toList(), cfg.priceLineRegex);
    }
    private List<Market.Listing> listings(Minecraft mc, AbstractContainerScreen<?> screen) {
        List<Market.Listing> rows = new ArrayList<>();
        for (Slot slot : screen.getMenu().slots) {
            if (slot.index >= cfg.listingSlotLimit || slot.container == mc.player.getInventory() || !slot.hasItem()) continue;
            ItemStack item = slot.getItem();
            OptionalLong p = price(item);
            if (p.isPresent()) rows.add(new Market.Listing(slot.index, key(item), BuiltInRegistries.ITEM.getKey(item.getItem()).toString(), item.getCount(), p.getAsLong()));
        }
        return rows;
    }
    private int inventoryCount(Minecraft mc, String wanted) {
        int count = 0;
        for (int i = 0; i < 36; i++) {
            var stack = mc.player.getInventory().getItem(i);
            if (!stack.isEmpty() && key(stack).equals(wanted)) count += stack.getCount();
        }
        return count;
    }
    private void tick(Minecraft mc) throws IOException {
        if (mc.player == null || mc.gameMode == null || !onServer(mc)) { halt("Sunucu bağlantısı uygun değil."); return; }
        if (phase != Phase.SCAN && --deadline <= 0) { halt("İşlem zaman aşımı. Otomatik tekrar yok; envanteri ve auction geçmişini kontrol et."); return; }
        if (++ticks < (phase == Phase.SCAN ? cfg.intervalTicks : 10)) return;
        ticks = 0;
        switch (phase) {
            case SCAN -> scan(mc);
            case CONFIRM -> confirm(mc);
            case RECEIVE -> receive(mc);
            case SELL -> {
                if (inventoryCount(mc, pending.listing().key()) == 0) {
                    ledger.unresolved = ""; atomicWrite(LEDGER, ledger);
                    mc.player.getInventory().setSelectedSlot(oldHotbar);
                    mc.player.connection.send(new net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket(oldHotbar));
                    say("Eşya envanterden çıktı; ilan komutu işlendi. Gerçekleşmiş satış/kâr henüz doğrulanmadı.");
                    phase = Phase.SCAN; pending = null;
                }
            }
        }
    }
    private void scan(Minecraft mc) throws IOException {
        if (!(mc.screen instanceof AbstractContainerScreen<?> screen)) {
            if (armed && mc.screen == null) mc.player.connection.sendCommand(cfg.auctionCommand);
            return;
        }
        if (!cfg.titleMatches(cfg.auctionTitleRegex, screen.getTitle().getString())) return;
        var rows = listings(mc, screen);
        String scan = screen.getTitle().getString() + " | " + rows.size();
        if (!scan.equals(lastScan)) {
            say("Auction okunuyor: " + rows.size() + " fiyatlı ilan; " + screen.getTitle().getString() + ". Alış modu=" + armed);
            lastScan = scan;
        }
        var references = SalesFeed.read(DIR.resolve("donut-trader-market.json"), System.currentTimeMillis());
        var eligible = new HashSet<>(cfg.allowedItems);
        if (cfg.requireRecentSales || cfg.useWebReference) {
            if (cfg.requireRecentSales) eligible.retainAll(references.keySet());
            if (cfg.useWebReference) eligible.retainAll(webMarket.prices(System.currentTimeMillis()).keySet());
            rows = rows.stream().filter(l -> {
                var stack = screen.getMenu().getSlot(l.slot()).getItem().copy();
                stack.remove(DataComponents.LORE); stack.setCount(1);
                return stack.getComponents().equals(new ItemStack(stack.getItem()).getComponents());
            }).toList();
        }
        Map<String, Long> caps = new HashMap<>();
        if (cfg.requireRecentSales) references.forEach((id, quote) -> caps.put(id, Market.toMinor(quote.unitSalePrice())));
        if (cfg.useWebReference) webMarket.prices(System.currentTimeMillis()).forEach((id, price) -> caps.merge(id, Market.toMinor(price), Math::min));
        var deal = Market.best(rows, eligible, Math.max(0, Market.toMinor(cfg.budget) - ledger.committed), cfg.minNetMargin, cfg.saleFee, cfg.undercut, cfg.minPeers,
                cfg.requireRecentSales || cfg.useWebReference ? caps : null);
        if (deal.isEmpty()) { if (armed) mc.player.closeContainer(); return; }
        var d = deal.get(); var l = d.listing();
        String signature = l.key() + ":" + l.price() + ":" + d.salePrice();
        if (!signature.equals(lastOffer)) { say("Fırsat: " + l.itemId() + " x" + l.count() + " alış=" + Market.formatMinor(l.price()) + " ilan=" + Market.formatMinor(d.salePrice()) + " tahmini net=" + Market.formatMinor(d.netProfit())); lastOffer = signature; }
        if (!armed) return;
        // Require no identical existing stack to unambiguously identify the received purchase.
        if (inventoryCount(mc, l.key()) != 0 || mc.player.getInventory().getFreeSlot() < 0) return;
        var live = screen.getMenu().getSlot(l.slot()).getItem();
        if (!key(live).equals(l.key()) || live.getCount() != l.count() || price(live).orElse(-1) != l.price()) return;
        pending = d;
        ledger.reserve(l.price(), Market.toMinor(cfg.budget));
        ledger.unresolved = "Alış başlatıldı: " + l.itemId() + " x" + l.count() + " @" + Market.formatMinor(l.price());
        atomicWrite(LEDGER, ledger); // Persist reservation BEFORE any irreversible click.
        phase = Phase.CONFIRM; deadline = cfg.timeoutTicks;
        mc.gameMode.handleInventoryMouseClick(screen.getMenu().containerId, l.slot(), 0, ClickType.PICKUP, mc.player);
    }
    private void confirm(Minecraft mc) throws IOException {
        if (!(mc.screen instanceof AbstractContainerScreen<?> screen)) return;
        if (!cfg.titleMatches(cfg.confirmTitleRegex, screen.getTitle().getString())) return;
        var slots = screen.getMenu().slots;
        if (cfg.confirmButtonSlot >= slots.size() || cfg.confirmItemSlot >= slots.size()) { halt("Onay slotu geçersiz."); return; }
        Slot button = slots.get(cfg.confirmButtonSlot), itemSlot = slots.get(cfg.confirmItemSlot);
        var item = itemSlot.getItem(); var l = pending.listing();
        if (button.container == mc.player.getInventory() || itemSlot.container == mc.player.getInventory()
                || !button.getItem().getHoverName().getString().equals(cfg.confirmButtonName)
                || !key(item).equals(l.key()) || item.getCount() != l.count() || price(item).orElse(-1) != l.price()) {
            halt("Onay ekranındaki eşya/fiyat/profil eşleşmedi."); return;
        }
        ledger.unresolved = "Alış onaylandı; teslim bekleniyor: " + l.itemId(); atomicWrite(LEDGER, ledger);
        phase = Phase.RECEIVE; deadline = cfg.timeoutTicks;
        mc.gameMode.handleInventoryMouseClick(screen.getMenu().containerId, cfg.confirmButtonSlot, 0, ClickType.PICKUP, mc.player);
    }
    private void receive(Minecraft mc) throws IOException {
        var l = pending.listing();
        int count = inventoryCount(mc, l.key());
        if (count == 0) return;
        if (count != l.count()) { halt("Teslim edilen adet farklı; elle kontrol et."); return; }
        if (mc.screen != null) { mc.player.closeContainer(); return; }
        var inventory = mc.player.getInventory();
        int index = -1;
        for (int i = 0; i < 36; i++) if (key(inventory.getItem(i)).equals(l.key()) && inventory.getItem(i).getCount() == l.count()) { index = i; break; }
        if (index < 0) { halt("Satılacak tam yığın bulunamadı."); return; }
        if (index != 0) {
            mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, index < 9 ? index + 36 : index, 0, ClickType.SWAP, mc.player);
            return; // Wait for the actual hotbar update; never issue sell from the old slot.
        }
        oldHotbar = inventory.getSelectedSlot();
        inventory.setSelectedSlot(0);
        mc.player.connection.send(new net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket(0));
        ledger.unresolved = "Satış komutu gönderiliyor: " + l.itemId() + " @" + Market.formatMinor(pending.salePrice()); atomicWrite(LEDGER, ledger);
        phase = Phase.SELL; deadline = cfg.timeoutTicks;
        mc.player.connection.sendCommand(cfg.sellCommand.replace("%d", Market.formatMinor(pending.salePrice())));
    }
    private void captureScreen(Minecraft mc) {
        if (mc.player == null || !(mc.screen instanceof AbstractContainerScreen<?> screen)) return;
        List<String> lines = new ArrayList<>();
        lines.add("Title: " + screen.getTitle().getString());
        for (Slot slot : screen.getMenu().slots) {
            if (slot.container == mc.player.getInventory() || !slot.hasItem()) continue;
            var item = slot.getItem();
            lines.add("Slot " + slot.index + " | " + BuiltInRegistries.ITEM.getKey(item.getItem()) + " x" + item.getCount() + " | " + item.getHoverName().getString());
            var plain = item.copy(); plain.remove(DataComponents.LORE); plain.setCount(1);
            lines.add("  [Diagnostic] PlainForWeb=" + plain.getComponents().equals(new ItemStack(plain.getItem()).getComponents()));
            var lore = item.get(DataComponents.LORE);
            if (lore != null) for (var line : lore.lines()) lines.add("  " + line.getString());
        }
        lastInspection = List.copyOf(lines);
        if (!screen.getTitle().getString().matches(AuctionProfile.TITLE)) lastNonListingInspection = lastInspection;
    }
    private void inspect(boolean nonListing) {
        List<String> lines = nonListing ? lastNonListingInspection : lastInspection;
        if (lines.isEmpty()) { say("Önce ilgili ekranı açıp kapat. Onay ekranı otomatik varsayılmaz; son liste dışı ekran kaydedilir."); return; }
        String name = nonListing ? "donut-trader-confirm.txt" : "donut-trader-inspect.txt";
        try { Files.write(DIR.resolve(name), lines); say("Ekran bilgileri config/" + name + " dosyasına yazıldı: " + lines.get(0)); }
        catch (IOException e) { say("İnceleme dosyası yazılamadı: " + e.getMessage()); }
    }
}
